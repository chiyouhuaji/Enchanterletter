package cn.autoforged.enchanter_letter.command;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7079;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class LetterDamageCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("letterdamage")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("damage_type", class_7079.method_41224(class_7924.field_42534))
                                .executes(LetterDamageCommand::execute))
        );
    }

    @SuppressWarnings("unchecked")
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (!(source.method_9228() instanceof class_1657 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player."));
            return 0;
        }
        class_1799 stack = player.method_6047();
        if (!ModEnchantments.hasMagicConversion(stack)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterdamage.no_enchantment"));
            return 0;
        }
        class_5321<?> rawKey = context.getArgument("damage_type", class_5321.class);
        var keyOpt = rawKey.method_39752(class_7924.field_42534);
        if (keyOpt.isEmpty()) {
            source.method_9213(class_2561.method_43469("command.enchanter_letter.letterdamage.invalid_type", rawKey.method_29177().toString()));
            return 0;
        }
        class_5321<class_8110> damageTypeKey = keyOpt.get();
        String damageTypeStr = damageTypeKey.method_29177().toString();

        if (!ModEnchantments.isValidDamageType(source.method_30497(), damageTypeKey.method_29177())) {
            source.method_9213(class_2561.method_43469("command.enchanter_letter.letterdamage.invalid_type", damageTypeStr));
            return 0;
        }
        stack.method_57379(ModDataComponents.CONVERSION_DAMAGE_TYPE, damageTypeStr);
        source.method_9226(() -> class_2561.method_43469("command.enchanter_letter.letterdamage.success", damageTypeStr), true);
        return 1;
    }
}