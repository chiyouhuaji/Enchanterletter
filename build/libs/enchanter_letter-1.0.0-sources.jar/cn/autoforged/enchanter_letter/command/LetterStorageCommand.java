package cn.autoforged.enchanter_letter.command;

import cn.autoforged.enchanter_letter.network.LetterStoragePayloads;
import cn.autoforged.enchanter_letter.storage.LetterStorageManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

/**
 * /letterstorage 截取实体并交换槽位物品命令（权限 2/3/4）：
 * /letterstorage                    进入/退出“截取实体”交互模式（退出时清空截取数据）
 * /letterstorage hand              交换截取实体主手 与 玩家手持物品
 * /letterstorage offhand           交换截取实体副手 与 玩家手持物品
 * /letterstorage armor <slot>      交换截取实体盔甲槽(head/chest/legs/feet) 与 玩家手持物品
 * /letterstorage nbt               输出截取实体的完整 NBT（消息栏点击复制）
 */
public class LetterStorageCommand {
    private static final String[] ARMOR_SLOTS = {"head", "chest", "legs", "feet"};

    private static final SuggestionProvider<class_2168> ARMOR_SUGGESTIONS =
            (context, builder) -> {
                for (String s : ARMOR_SLOTS) builder.suggest(s);
                return builder.buildFuture();
            };

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("letterstorage")
                .requires(source -> source.method_9259(2))
                .executes(LetterStorageCommand::toggleCommand)
                .then(class_2170.method_9247("hand")
                        .executes(ctx -> swapSlot(ctx, class_1304.field_6173)))
                .then(class_2170.method_9247("offhand")
                        .executes(ctx -> swapSlot(ctx, class_1304.field_6171)))
                .then(class_2170.method_9247("armor")
                        .then(class_2170.method_9244("slot", StringArgumentType.word())
                                .suggests(ARMOR_SUGGESTIONS)
                                .executes(LetterStorageCommand::swapArmor)))
                .then(class_2170.method_9247("nbt")
                        .executes(LetterStorageCommand::nbtCommand)));
    }

    /** /letterstorage：切换交互模式（开启 / 关闭并清空截取）。 */
    private static int toggleCommand(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.player_only"));
            return 0;
        }
        boolean now = LetterStorageManager.toggle(player);
        LetterStoragePayloads.sendModeToClient(player, now);
        if (now) {
            source.method_9226(() -> class_2561.method_43471("command.enchanter_letter.letterstorage.toggle_on"), true);
        } else {
            source.method_9226(() -> class_2561.method_43471("command.enchanter_letter.letterstorage.toggle_off"), true);
        }
        return 1;
    }

    /** /letterstorage armor <head|chest|legs|feet>。 */
    private static int swapArmor(CommandContext<class_2168> context) throws CommandSyntaxException {
        String slot = context.getArgument("slot", String.class);
        class_1304 target;
        switch (slot.toLowerCase()) {
            case "head": target = class_1304.field_6169; break;
            case "chest": target = class_1304.field_6174; break;
            case "legs": target = class_1304.field_6172; break;
            case "feet": target = class_1304.field_6166; break;
            default:
                context.getSource().method_9213(class_2561.method_43469(
                        "command.enchanter_letter.letterstorage.invalid_slot", slot));
                return 0;
        }
        return swapSlot(context, target);
    }

    /** 交换截取实体指定槽位物品 与 玩家手持物品。 */
    private static int swapSlot(CommandContext<class_2168> context, class_1304 target) {
        class_2168 source = context.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.player_only"));
            return 0;
        }
        if (!LetterStorageManager.isCapturing(player)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.not_in_mode"));
            return 0;
        }
        class_1297 captured = LetterStorageManager.resolveCaptured(source.method_9211(), player);
        if (captured == null) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.no_capture"));
            return 0;
        }
        if (!(captured instanceof class_1309 living)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.no_slots"));
            return 0;
        }
        class_1799 entityItem = living.method_6118(target).method_7972();
        class_1799 playerItem = player.method_6047().method_7972();
        living.method_5673(target, playerItem);
        // 实体原槽位物品回到玩家主手
        player.method_31548().method_5447(player.method_31548().field_7545, entityItem);
        String name = captured.method_5476().getString();
        source.method_9226(() -> class_2561.method_43469(
                "command.enchanter_letter.letterstorage.swap_success", name, slotLabel(target)), true);
        return 1;
    }

    /** /letterstorage nbt：实时获取截取实体的完整 NBT 并输出（可点击复制）。 */
    private static int nbtCommand(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.player_only"));
            return 0;
        }
        // 再次获取实体，保持数据最新；实体不存在则立即清空截取数据
        class_1297 captured = LetterStorageManager.resolveCaptured(source.method_9211(), player);
        if (captured == null) {
            source.method_9213(class_2561.method_43471("command.enchanter_letter.letterstorage.no_capture"));
            return 0;
        }
        class_2487 tag = new class_2487();
        captured.method_5647(tag);
        String nbt = tag.toString();
        class_5250 header = class_2561.method_43469(
                "command.enchanter_letter.letterstorage.nbt_header", captured.method_5476().getString());
        class_2561 clickable = class_2561.method_43470(nbt).method_27694(style -> style
                .method_10977(class_124.field_1075)
                .method_10949(new class_2568(class_2568.class_5247.field_24342,
                        class_2561.method_43471("command.enchanter_letter.letterstorage.nbt_copy_hint")))
                .method_10958(new class_2558(class_2558.class_2559.field_21462, nbt)));
        player.method_43496(header.method_27693(" ").method_10852(clickable));
        return 1;
    }

    private static String slotLabel(class_1304 slot) {
        switch (slot) {
            case field_6169: return "头部";
            case field_6174: return "胸部";
            case field_6172: return "腿部";
            case field_6166: return "脚部";
            case field_6171: return "副手";
            default: return "主手";
        }
    }
}
