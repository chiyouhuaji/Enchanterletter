package cn.autoforged.enchanter_letter.event;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import cn.autoforged.enchanter_letter.integration.AccessoriesIntegration;
import cn.autoforged.enchanter_letter.integration.CuriosIntegration;
import cn.autoforged.enchanter_letter.item.LetterBinderItem;
import cn.autoforged.enchanter_letter.item.MagicLetterItem;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * 手札对实体（玩家/生物）的附加效果（Fabric 1.20.1 移植，物品数据用 NBT）：
 * - 光灵附魔：持有者发光（RGB 平均混合，经 /lettercolor 或 NBT 调色；统一用队伍颜色近似）；
 * - 消失诅咒（生物）：装备有该附魔的手札/合订本立即绑定零 UUID 防止窃取；
 * - 定时清理：每 N 秒清理绑定到配置名单 UUID 的手札/合订本掉落物；
 * - 死亡处理：玩家魔法绑定物品保留重生返还；消失诅咒物品死亡移除，
 *   合订本内的非诅咒手札返还物品栏（溢出在重生点生成掉落物）。
 */
public class LetterEntityEffects {
    /** 发光队伍名前缀（队伍按实体 id 命名，长度受 16 字符限制）。 */
    private static final String TEAM_PREFIX = "elg_";

    /** 死亡保留物品：物品 + 原饰品槽位信息（curioType/index；非饰品槽为 null/-1；accessories 槽另存 name/index）。 */
    private static class KeptItem {
        final class_1799 stack;
        final String curioType;
        final int curioIndex;
        final boolean accessories;
        /** 是否已处理完成（成功装回槽位或已放入背包），用于重试时避免重复归还。 */
        boolean restored;

        KeptItem(class_1799 stack, String curioType, int curioIndex, boolean accessories) {
            this.stack = stack;
            this.curioType = curioType;
            this.curioIndex = curioIndex;
            this.accessories = accessories;
        }
    }

    /** 死亡保留池：UUID -> 需在重生时返还的物品（魔法绑定物品，含饰品槽原位）。 */
    private static final Map<UUID, List<KeptItem>> DEATH_KEEP_POOL = new HashMap<>();

    /** 饰品装回失败后的额外重试时长（tick）：重生槽位延迟就绪时逐 tick 重试，超时后回退背包。 */
    private static final int MAX_RESTORE_RETRY_TICKS = 60;

    /** 待处理的重生任务：经 /letterdelay 延迟（游戏刻）后执行饰品原位装回与消失诅咒检查。 */
    private static class PendingRespawn {
        final List<KeptItem> keep;
        int countdown;
        int retriesLeft;

        PendingRespawn(List<KeptItem> keep, int countdown) {
            this.keep = keep;
            this.countdown = countdown;
            this.retriesLeft = MAX_RESTORE_RETRY_TICKS;
        }
    }

    /** 重生待处理队列：UUID -> 延迟任务（延迟结束后装回保留物品并扫描删除消失诅咒物品）。 */
    private static final Map<UUID, PendingRespawn> PENDING_RESPAWNS = new HashMap<>();

    /** 已施加的队伍颜色缓存（实体 UUID -> 上次使用的颜色），用于避免重复改队伍颜色省包。 */
    private static final Map<UUID, class_124> appliedGlowColor = new HashMap<>();

    private static int glowCooldown = 10;
    private static int cleanCooldown = 20;
    private static int teamSweepCooldown = 600;

    private LetterEntityEffects() {
    }

    /** 服务器 tick 调用：发光同步、零 UUID 绑定、掉落物定时清理、重生延迟任务。 */
    public static void tick(MinecraftServer server) {
        if (--glowCooldown <= 0) {
            glowCooldown = 10;
            syncGlowAndZeroBinding(server);
        }
        if (--teamSweepCooldown <= 0) {
            teamSweepCooldown = 600;
            sweepTeams(server);
        }
        if (--cleanCooldown <= 0) {
            cleanCooldown = Math.max(20, (int) (ModConfig.getInstance().letterCleanup.intervalSeconds * 20));
            cleanupBoundDrops(server);
        }
        tickPendingRespawns(server);
    }

    // ==================== 光灵发光 ====================

    private static void syncGlowAndZeroBinding(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            applyGlow(player, collectGlowColors(player));
        }
        for (class_3218 level : server.method_3738()) {
            for (class_1309 entity : level.method_18198(net.minecraft.class_5575.method_31795(net.minecraft.class_1309.class),
                    ent -> !(ent instanceof class_1657))) {
                applyGlow(entity, collectGlowColors(entity));
            }
        }
    }

    /** 收集实体携带的全部光灵颜色（玩家含背包/饰品/合订本内容；生物为装备槽）。 */
    private static List<Integer> collectGlowColors(class_1657 player) {
        List<Integer> colors = new ArrayList<>();
        scanPlayerSlots(player, stack -> {
            if (ModEnchantments.hasGlowing(stack)) {
                colors.add(ModEnchantments.getGlowColorOrDefault(stack));
            }
        });
        return colors;
    }

    private static List<Integer> collectGlowColors(class_1309 entity) {
        List<Integer> colors = new ArrayList<>();
        for (class_1799 stack : entity.method_5661()) collectGlowColor(stack, colors);
        for (class_1799 stack : entity.method_5877()) collectGlowColor(stack, colors);
        // 饰品槽（生物也可能佩戴饰品）；玩家路径在 scanPlayerSlots 已含 Curios/Accessories
        for (class_1799 stack : CuriosIntegration.getCuriosStacks(entity)) collectGlowColor(stack, colors);
        for (class_1799 stack : AccessoriesIntegration.getAccessoriesStacks(entity)) collectGlowColor(stack, colors);
        return colors;
    }

    private static void collectGlowColor(class_1799 stack, List<Integer> colors) {
        if (stack.method_7960() || !ModEnchantments.hasGlowing(stack)) return;
        colors.add(ModEnchantments.getGlowColorOrDefault(stack));
    }

    /** RGB 平均混合：各通道取均值；全 0 视为白色。 */
    private static int averageColor(List<Integer> colors) {
        if (colors.isEmpty()) return 0xFFFFFF;
        int r = 0, g = 0, b = 0;
        for (int c : colors) {
            r += (c >> 16) & 0xFF;
            g += (c >> 8) & 0xFF;
            b += c & 0xFF;
        }
        int n = colors.size();
        r = r / n;
        g = g / n;
        b = b / n;
        return (r << 16) | (g << 8) | b;
    }

    /** 发光：设置队伍颜色 + 发光标记；无光灵时清除。 */
    private static void applyGlow(class_1309 entity, List<Integer> colors) {
        if (colors.isEmpty()) {
            clearGlow(entity);
            return;
        }
        if (entity.method_37908().field_9236) return;
        int color = averageColor(colors);
        class_124 fmt = nearestFormatting(color);
        UUID uuid = entity.method_5667();
        String teamName = TEAM_PREFIX + entity.method_5628();
        class_269 scoreboard = entity.method_37908().method_8428();
        class_268 team = scoreboard.method_1153(teamName);
        if (team == null) {
            team = scoreboard.method_1171(teamName);
        }
        // 颜色变化时才更新队伍颜色（避免每 tick 刷队色更新包）
        class_124 prev = appliedGlowColor.get(uuid);
        if (prev != fmt) {
            team.method_1141(fmt);
            appliedGlowColor.put(uuid, fmt);
        }
        // 幂等：把实体加入队伍（addPlayerToTeam 会自动从原队伍移除）
        scoreboard.method_1172(entity.method_5820(), team);
        entity.method_5834(true);
        if (appliedGlowColor.size() > 5000) {
            // 兜底防无限增长（正常会在 clearGlow/sweepTeams 中移除）
            appliedGlowColor.clear();
        }
    }

    private static void clearGlow(class_1309 entity) {
        if (entity.method_37908().field_9236) return;
        boolean wasApplied = appliedGlowColor.remove(entity.method_5667()) != null;
        if (entity.method_36361()) {
            entity.method_5834(false);
        }
        class_269 scoreboard = entity.method_37908().method_8428();
        String teamName = TEAM_PREFIX + entity.method_5628();
        class_268 team = scoreboard.method_1153(teamName);
        if (team == null) return;
        // 仅当本模组曾把该实体加入 elg_ 队伍时才移除，避免误拆其他模组/原版的队伍关系
        if (wasApplied) {
            scoreboard.method_1157(entity.method_5820(), team);
        }
        if (team.method_1204().isEmpty()) {
            scoreboard.method_1191(team);
        }
    }

    /** 周期清理残留队伍（实体销毁后遗留）。 */
    private static void sweepTeams(MinecraftServer server) {
        for (class_3218 level : server.method_3738()) {
            class_269 scoreboard = level.method_14170();
            List<class_268> toRemove = new ArrayList<>();
            for (class_268 team : scoreboard.method_1159()) {
                if (team.method_1197().startsWith(TEAM_PREFIX) && team.method_1204().isEmpty()) {
                    toRemove.add(team);
                }
            }
            for (class_268 team : toRemove) {
                scoreboard.method_1191(team);
            }
        }
    }

    private static class_124 nearestFormatting(int color) {
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        class_124 best = class_124.field_1068;
        int bestDist = Integer.MAX_VALUE;
        for (class_124 fmt : class_124.values()) {
            if (!fmt.method_543()) continue;
            Integer c = fmt.method_532();
            if (c == null) continue;
            int fr = (c >> 16) & 0xFF, fg = (c >> 8) & 0xFF, fb = c & 0xFF;
            int dist = (fr - r) * (fr - r) + (fg - g) * (fg - g) + (fb - b) * (fb - b);
            if (dist < bestDist) {
                bestDist = dist;
                best = fmt;
            }
        }
        return best;
    }

    // ==================== 掉落物定时清理 ====================

    private static void cleanupBoundDrops(MinecraftServer server) {
        ModConfig.LetterCleanupConfig cfg = ModConfig.getInstance().letterCleanup;
        if (!cfg.enabled || cfg.targetUuids.isEmpty()) return;
        Set<String> targets = new HashSet<>(cfg.targetUuids);
        for (class_3218 level : server.method_3738()) {
            for (class_1542 itemEntity : level.method_18198(net.minecraft.class_5575.method_31795(net.minecraft.class_1542.class), e -> true)) {
                class_1799 stack = itemEntity.method_6983();
                if (stack.method_7960() || !ModCommonEvents.isOurModItem(stack)) continue;
                Optional<UUID> bound = stack.method_57824(ModDataComponents.BOUND_PLAYER);
                if (bound != null && bound.isPresent() && targets.contains(bound.get().toString())) {
                    itemEntity.method_31472();
                }
            }
        }
    }

    // ==================== 玩家死亡处理（魔法绑定保留 / 消失诅咒移除） ====================

    /** 玩家死亡（Player.die HEAD，掉落生成之前）：处理背包/盔甲/副手/饰品槽。 */
    public static void handlePlayerDeath(class_1657 player) {
        if (player.method_37908().field_9236) return;
        boolean vanish = ModConfig.getInstance().letterVanish.enabled;
        List<KeptItem> keep = new ArrayList<>();
        handleContainer(player, player.method_31548().field_7547, keep, vanish);
        handleContainer(player, player.method_31548().field_7548, keep, vanish);
        handleContainer(player, player.method_31548().field_7544, keep, vanish);
        // 饰品栏（Curios + Accessories）：死亡事件后、掉落机制前，先截取死亡瞬间饰品栏全部数据
        // （纯读取快照，不依赖槽位删除流程，跨版本通用），再处理快照：
        // - 魔法绑定物品：从原槽位取出保留（防止进入掉落列表），记录原槽位，重生延迟后强制装回原位并覆盖；
        // - 消失诅咒物品：取出销毁。
        boolean curiosDropRuleActive = CuriosIntegration.isDeathDropRuleActive();
        boolean accDropRuleActive = AccessoriesIntegration.isDeathDropRuleActive();
        if (curiosDropRuleActive) {
            // Curios 原生 DropRule：KEEP 会让魔法绑定物品留在原饰品槽位，不手动摘除/归还。
        } else {
            List<CuriosIntegration.CurioSocket> curiosSnapshot = CuriosIntegration.snapshotAllSlots(player);
            for (CuriosIntegration.CurioSocket cs : curiosSnapshot) {
                if (cs.stack.method_7960()) continue;
                boolean vanishItem = vanish && ModEnchantments.hasVanishing(cs.stack);
                if (vanishItem || ModEnchantments.hasEffectiveMagicBinding(cs.stack)) {
                    class_1799 removed = CuriosIntegration.removeStackFromSlot(player, cs.slotType, cs.slot);
                    if (removed.method_7960()) continue; // 取出失败：不保留（交由掉落兜底处理，避免复制）
                    if (vanishItem) continue; // 消失诅咒物品：直接销毁
                    keep.add(new KeptItem(removed, cs.slotType, cs.slot, false));
                }
            }
        }
        if (accDropRuleActive) {
            // Accessories 已注册原生 DropRule：KEEP 会让魔法绑定物品留在原饰品槽位，
            // 不再手动摘除/归还，避免“摘除成功但重生后无法装回原槽位”的问题。
        } else {
            List<AccessoriesIntegration.AccessoriesSocket> accSnapshot = AccessoriesIntegration.snapshotAllSlots(player);
            for (AccessoriesIntegration.AccessoriesSocket as : accSnapshot) {
                if (as.stack.method_7960()) continue;
                boolean vanishItem = vanish && ModEnchantments.hasVanishing(as.stack);
                if (vanishItem || ModEnchantments.hasEffectiveMagicBinding(as.stack)) {
                    class_1799 removed = AccessoriesIntegration.removeStackFromSlot(player, as.slotType, as.slot);
                    if (removed.method_7960()) continue; // 取出失败：不保留（交由掉落兜底处理，避免复制）
                    if (vanishItem) continue; // 消失诅咒物品：直接销毁
                    keep.add(new KeptItem(removed, as.slotType, as.slot, true));
                }
            }
        }
        if (!keep.isEmpty()) {
            DEATH_KEEP_POOL.put(player.method_5667(), keep);
        }
    }

    /**
     * PlayerInventory.dropAll HEAD 兜底：直接从实际掉落入口拦截魔法绑定/消失诅咒物品。
     * 与 Player.die HEAD 的预扫描互补——即使某些路径跳过了 die 预扫描，
     * 这里仍能在物品进入掉落列表前把它们移除并加入保留池。
     */
    public static void handlePlayerInventoryDropAll(class_1657 player) {
        if (player == null || player.method_37908().field_9236 || !player.method_29504()) return;
        boolean vanish = ModConfig.getInstance().letterVanish.enabled;
        var inv = player.method_31548();
        handleContainer(player, inv.field_7547, null, vanish);
        handleContainer(player, inv.field_7548, null, vanish);
        handleContainer(player, inv.field_7544, null, vanish);
    }

    private static void handleContainer(class_1657 player, List<class_1799> container, List<KeptItem> keep, boolean vanish) {
        for (int i = 0; i < container.size(); i++) {
            class_1799 stack = container.get(i);
            if (stack.method_7960()) continue;
            if (vanish && ModEnchantments.hasVanishing(stack)) {
                container.set(i, class_1799.field_8037); // 强制消失：销毁（即使开启原版死亡不掉落）
            } else if (ModEnchantments.hasEffectiveMagicBinding(stack)) {
                if (keep != null) {
                    keep.add(new KeptItem(stack.method_7972(), null, -1, false));
                } else {
                    addToKeepPool(player, stack);
                }
                container.set(i, class_1799.field_8037);
            }
        }
    }

    /**
     * 重生：登记延迟返还任务。等待 /letterdelay（游戏刻，默认 20）后：
     * 1) 返还死亡保留池（魔法绑定物品；饰品槽物品强制装回原栏位并覆盖，否则回退背包/掉落）；
     * 2) 扫描玩家全部槽位并立即删除消失诅咒物品（强制消失开启时）。
     * 延迟等待是为了让饰品槽位/背包在重生后加载完成，避免有槽位却装回失败。
     */
    public static void onPlayerRespawn(class_1657 player) {
        if (player.method_37908().field_9236) return;
        List<KeptItem> keep = DEATH_KEEP_POOL.remove(player.method_5667());
        int delay = Math.max(0, ModConfig.getInstance().letterRespawn.restoreDelayTicks);
        PENDING_RESPAWNS.put(player.method_5667(), new PendingRespawn(keep == null ? List.of() : keep, delay));
    }

    /** 每 tick 处理重生延迟任务：倒计时归零后执行饰品原位装回 + 消失诅咒物品扫描删除。 */
    private static void tickPendingRespawns(MinecraftServer server) {
        if (PENDING_RESPAWNS.isEmpty()) return;
        List<UUID> finished = new ArrayList<>();
        for (Map.Entry<UUID, PendingRespawn> entry : new ArrayList<>(PENDING_RESPAWNS.entrySet())) {
            PendingRespawn pending = entry.getValue();
            if (pending.countdown > 0) {
                pending.countdown--;
                continue;
            }
            class_3222 player = server.method_3760().method_14602(entry.getKey());
            if (player != null) {
                boolean allRestored = restoreKeptItems(player, pending.keep);
                sweepVanishingItems(player);
                if (!allRestored && pending.retriesLeft > 0) {
                    // 饰品槽位可能尚未就绪（延迟加载/其他模组未初始化）：下一 tick 重试
                    pending.retriesLeft--;
                    pending.countdown = 1;
                    continue;
                }
                if (!allRestored) {
                    // 重试超时：仍未装回的饰品物品回退到背包（背包满则重生点掉落），避免滞留内存丢失
                    forceReturnKeptItems(player, pending.keep);
                }
            }
            finished.add(entry.getKey());
        }
        for (UUID uuid : finished) {
            PENDING_RESPAWNS.remove(uuid);
        }
    }

    /** 归还死亡保留物品：饰品槽物品强制装回原槽位并覆盖。返回是否全部装回成功（失败可稍后重试）。 */
    private static boolean restoreKeptItems(class_1657 player, List<KeptItem> keep) {
        boolean allDone = true;
        for (KeptItem ki : keep) {
            if (ki.restored) continue; // 已处理（成功装回槽位或已放入背包），避免重试重复归还
            if (ki.curioType != null) {
                // 强制装回原饰品槽位（直接覆盖该槽位，不经过背包临时存储，避免触发其他饰品逻辑导致复制）
                boolean restored = ki.accessories
                        ? AccessoriesIntegration.restoreStack(player, ki.curioType, ki.curioIndex, ki.stack)
                        : CuriosIntegration.restoreStack(player, ki.curioType, ki.curioIndex, ki.stack);
                if (restored) {
                    ki.restored = true;
                    continue;
                }
                allDone = false; // 槽位暂不可用：保留待重试
                continue;
            }
            if (!player.method_31548().method_7394(ki.stack)) {
                spawnDrop(player, ki.stack);
            }
            ki.restored = true;
        }
        return allDone;
    }

    /** 重试超时后兜底：把仍未装回的饰品物品放入背包（背包满则重生点掉落）。 */
    private static void forceReturnKeptItems(class_1657 player, List<KeptItem> keep) {
        for (KeptItem ki : keep) {
            if (ki.restored) continue;
            if (!player.method_31548().method_7394(ki.stack)) {
                spawnDrop(player, ki.stack);
            }
            ki.restored = true;
        }
    }

    /**
     * 消失诅咒延迟检查：强制消失开启时，扫描玩家全部槽位（背包/盔甲/副手/饰品栏，
     * 含合订本内容物），检测到带消失诅咒附魔的物品立即删除。
     */
    private static void sweepVanishingItems(class_1657 player) {
        if (!ModConfig.getInstance().letterVanish.enabled) return;
        var inv = player.method_31548();
        sweepContainer(player, inv.field_7547);
        sweepContainer(player, inv.field_7548);
        sweepContainer(player, inv.field_7544);
        // 饰品栏：带消失诅咒的物品直接销毁
        CuriosIntegration.ejectStacksWhere(player, ModEnchantments::hasVanishing, stack -> { });
        AccessoriesIntegration.ejectStacksWhere(player, ModEnchantments::hasVanishing, stack -> { });
        // 饰品栏内的合订本：扫描并删除内容物中的消失诅咒物品
        for (class_1799 stack : CuriosIntegration.getCuriosStacks(player)) {
            sweepBinderContents(player, stack);
        }
        for (class_1799 stack : AccessoriesIntegration.getAccessoriesStacks(player)) {
            sweepBinderContents(player, stack);
        }
    }

    private static void sweepContainer(class_1657 player, List<class_1799> container) {
        for (int i = 0; i < container.size(); i++) {
            class_1799 stack = container.get(i);
            if (stack.method_7960()) continue;
            if (ModEnchantments.hasVanishing(stack)) {
                container.set(i, class_1799.field_8037); // 检测到消失诅咒物品：立即删除
                continue;
            }
            sweepBinderContents(player, stack);
        }
    }

    /** 扫描合订本内容物：删除带消失诅咒的内部物品（合订本本身带消失诅咒时整体销毁）。 */
    private static void sweepBinderContents(class_1657 player, class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof LetterBinderItem)) return;
        net.minecraft.class_9276 contents = stack.method_57825(
                net.minecraft.class_9334.field_49650,
                net.minecraft.class_9276.field_49289);
        if (ModEnchantments.hasVanishing(stack)) {
            // 合订本本身带消失诅咒：整体销毁（含内容物）
            stack.method_7939(0);
            return;
        }
        if (contents.method_57429()) return;
        List<class_1799> keep = new ArrayList<>();
        boolean changed = false;
        for (class_1799 inner : contents.method_59708()) {
            if (inner.method_7960()) continue;
            if (ModEnchantments.hasVanishing(inner)) {
                changed = true; // 内容物中的消失诅咒物品：删除
            } else {
                keep.add(inner);
            }
        }
        if (changed) {
            stack.method_57379(net.minecraft.class_9334.field_49650,
                    new net.minecraft.class_9276(keep));
        }
    }

    /** 把掉落中的魔法绑定物品加入保留池（ENTITY_LOAD 兜底）；重生时归还。 */
    public static void addToKeepPool(class_1657 player, class_1799 stack) {
        List<KeptItem> list = DEATH_KEEP_POOL.computeIfAbsent(player.method_5667(), k -> new ArrayList<>());
        list.add(new KeptItem(stack.method_7972(), null, -1, false));
    }

    /** 玩家登出：清空保留池与待处理的重生任务（物品已随存档保留，直接丢弃引用）。 */
    public static void onPlayerLogout(UUID playerUuid) {
        DEATH_KEEP_POOL.remove(playerUuid);
        PENDING_RESPAWNS.remove(playerUuid);
    }

    private static void spawnDrop(class_1657 player, class_1799 stack) {
        class_1542 drop = new class_1542(player.method_37908(), player.method_23317(), player.method_23318(), player.method_23321(), stack);
        drop.method_18800(0, 0, 0);
        player.method_37908().method_8649(drop);
    }

    // ==================== 生物死亡处理（消失诅咒移除） ====================

    /** 生物死亡（LivingDeathEvent，掉落生成前）：移除装备上的消失诅咒物品。 */
    public static void handleMobDeath(class_1309 entity) {
        if (entity.method_37908().field_9236 || entity instanceof class_1657) return;
        if (!ModConfig.getInstance().letterVanish.enabled) return;
        for (class_1799 stack : entity.method_5661()) handleMobVanishing(stack);
        for (class_1799 stack : entity.method_5877()) handleMobVanishing(stack);
    }

    private static void handleMobVanishing(class_1799 stack) {
        if (stack.method_7960() || !ModEnchantments.hasVanishing(stack)) return;
        stack.method_7939(0);
    }

    /** 玩家槽位扫描（含饰品栏/合订本内容物）。 */
    private static void scanPlayerSlots(class_1657 player, java.util.function.Consumer<class_1799> consumer) {
        var inv = player.method_31548();
        for (var stack : inv.field_7547) scanStack(stack, consumer);
        for (var stack : inv.field_7548) scanStack(stack, consumer);
        for (var stack : inv.field_7544) scanStack(stack, consumer);
        for (var stack : CuriosIntegration.getCuriosStacks(player)) scanStack(stack, consumer);
        for (var stack : AccessoriesIntegration.getAccessoriesStacks(player)) scanStack(stack, consumer);
    }

    private static void scanStack(class_1799 stack, java.util.function.Consumer<class_1799> consumer) {
        if (stack.method_7960()) return;
        consumer.accept(stack);
        if (stack.method_7909() instanceof LetterBinderItem) {
            net.minecraft.class_9276 contents = stack.method_57825(
                    net.minecraft.class_9334.field_49650,
                    net.minecraft.class_9276.field_49289);
            for (class_1799 inner : contents.method_59708()) {
                if (!inner.method_7960()) consumer.accept(inner);
            }
        }
    }
}