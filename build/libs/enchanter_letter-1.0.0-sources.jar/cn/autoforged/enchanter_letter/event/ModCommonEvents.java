package cn.autoforged.enchanter_letter.event;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import cn.autoforged.enchanter_letter.integration.AccessoriesIntegration;
import cn.autoforged.enchanter_letter.integration.CuriosIntegration;
import cn.autoforged.enchanter_letter.item.LetterStats;
import cn.autoforged.enchanter_letter.item.ExperienceMagicLetterItem;
import cn.autoforged.enchanter_letter.item.FishingMagicLetterItem;
import cn.autoforged.enchanter_letter.item.HeroMagicLetterItem;
import cn.autoforged.enchanter_letter.item.KillMagicLetterItem;
import cn.autoforged.enchanter_letter.item.LetterBinderItem;
import cn.autoforged.enchanter_letter.item.MagicLetterItem;
import cn.autoforged.enchanter_letter.item.ModItems;
import cn.autoforged.enchanter_letter.item.TenacityMagicLetterItem;
import cn.autoforged.enchanter_letter.item.TimeMagicLetterItem;
import cn.autoforged.enchanter_letter.item.TravelMagicLetterItem;
import cn.autoforged.enchanter_letter.item.TreasureMagicLetterItem;
import cn.autoforged.enchanter_letter.storage.LetterStorageManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import net.minecraft.class_9276;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.Map.Entry;

public class ModCommonEvents {
    static final class_5321<class_8110> USEFULMAGIC_MAGIC =
            class_5321.method_29179(class_7924.field_42534, class_2960.method_60654("usefulmagic:magic"));

    /** /kill 指令使用的伤害类型（不再计入坚韧手札承受伤害计数）。 */
    private static final class_5321<class_8110> GENERIC_KILL =
            class_5321.method_29179(class_7924.field_42534, class_2960.method_60656("generic_kill"));

    private static final int MAX_PENDING_TYPES_PER_VICTIM = 16;
    private static final int MAX_PENDING_VICTIMS = 200;
    private static final int MAX_STALE_TICKS = 100;
    private static final int BIND_CHECK_INTERVAL = 20;
    private static final double MAX_TRAVEL_PER_TICK = 100.0;
    /** 旅行距离采样间隔（tick）：每 tick 全槽轮询会持续扫描在线玩家槽位，
     *  最低加入 1 tick（0.05 秒）延迟，这里取 2 tick 采样一次。 */
    private static final int TRAVEL_POLL_INTERVAL = 2;
    private static final int ACCESSORY_COMPAT_INTERVAL = 100;
    private static final int ARMOR_SYNC_INTERVAL = 10;

    private static int accessoryCompatCooldown = ACCESSORY_COMPAT_INTERVAL;
    private static int bindCheckCooldown = BIND_CHECK_INTERVAL;
    private static int armorSyncCooldown = ARMOR_SYNC_INTERVAL;
    private static int travelPollCooldown = 0;

    private static final ThreadLocal<UUID> CONVERSION_IN_PROGRESS = new ThreadLocal<>();

    private static final Map<UUID, class_243> lastTravelPos = new HashMap<>();

    static class PendingEntry {
        final class_5321<class_8110> damageType;
        float amount;
        class_1297 directEntity;
        class_1297 sourceEntity;

        PendingEntry(class_5321<class_8110> damageType, float amount, class_1297 directEntity, class_1297 sourceEntity) {
            this.damageType = damageType;
            this.amount = amount;
            this.directEntity = directEntity;
            this.sourceEntity = sourceEntity;
        }
    }

    static class ConversionDamageState {
        final Map<class_5321<class_8110>, PendingEntry> pendingByType = new LinkedHashMap<>();
        int countdown;
        int staleTicks;
    }

    private static final Map<UUID, ConversionDamageState> pendingDamages = new HashMap<>();

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            // 杀戮手札：持有者（玩家或生物）击杀任意生物/玩家 +1
            if (source.method_5529() instanceof class_1309 killer) {
                scanEntitySlots(killer, stack -> {
                    if (stack.method_31574(ModItems.KILL_MAGIC_LETTER.get())) {
                        KillMagicLetterItem.addKill(stack);
                    }
                });
            }
            pendingDamages.remove(entity.method_5667());
        });

        // 重生：返还死亡保留池（魔法绑定物品 / 溢出的非诅咒手札）
        net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AFTER_RESPAWN.register(
                (oldPlayer, newPlayer, alive) -> LetterEntityEffects.onPlayerRespawn(newPlayer));

        // 登出：清空保留池引用 + /letterstorage 截取状态
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register(
                (handler, server) -> {
                    LetterEntityEffects.onPlayerLogout(handler.field_14140.method_5667());
                    LetterStorageManager.onLogout(handler.field_14140.method_5667());
                });

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof class_1542 itemEntity)) return;
            class_1799 stack = itemEntity.method_6983();
            if (stack.method_7960()) return;
            // 强制消失开启时：带有消失诅咒的物品一律阻止形成掉落物（包括生物的 NBT 装备转成掉落物）
            if (ModConfig.getInstance().letterVanish.enabled && ModEnchantments.hasVanishing(stack)) {
                entity.method_31472();
                return;
            }
            // 魔法绑定物品：持有人正死亡时兜底销毁并加入保留池（避免掉落丢失；重生时统一归还）
            if (ModEnchantments.hasEffectiveMagicBinding(stack)) {
                Optional<UUID> boundOpt = stack.method_57824(ModDataComponents.BOUND_PLAYER);
                if (boundOpt != null && boundOpt.isPresent() && world instanceof class_3218) {
                    class_3218 serverLevel = (class_3218) world;
                    class_1657 owner = serverLevel.method_18470(boundOpt.get());
                    if (owner != null && owner.method_29504()) {
                        LetterEntityEffects.addToKeepPool(owner, stack);
                        entity.method_31472();
                        return;
                    }
                }
            }
            if (isOurLetter(stack)) {
                // 手札掉落物：白色发光（方便找到物品）+ 无重力、静止不动
                entity.method_5834(true);
                entity.method_5875(true);
                entity.method_18800(0.0, 0.0, 0.0);
                Optional<UUID> boundOpt = stack.method_57824(ModDataComponents.BOUND_PLAYER);
                if (boundOpt != null && boundOpt.isPresent()) {
                    itemEntity.method_48349(boundOpt.get());
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (--bindCheckCooldown <= 0) {
                bindCheckCooldown = BIND_CHECK_INTERVAL;
                ejectForeignBoundLetters(server);
            }

            if (--accessoryCompatCooldown <= 0) {
                accessoryCompatCooldown = ACCESSORY_COMPAT_INTERVAL;
                CuriosIntegration.ensureAllSlotCompat();
                AccessoriesIntegration.ensureAllSlotCompat(server.method_30002());
            }

            // 累计所有在线玩家的行走/飞行距离（旅行魔法手札）：带冷却，避免每 tick 全槽轮询
            if (--travelPollCooldown <= 0) {
                travelPollCooldown = TRAVEL_POLL_INTERVAL;
                tickTravelDistances(server);
            }

            // 手札护甲值/护甲韧性：以原版属性 modifier 形式常驻叠加（护甲条/Overloaded Armor Bar 可见；生物同样生效）
            if (--armorSyncCooldown <= 0) {
                armorSyncCooldown = ARMOR_SYNC_INTERVAL;
                for (var player : server.method_3760().method_14571()) {
                    LetterStats.syncArmorModifiers(player);
                }
                for (class_3218 level : server.method_3738()) {
                    for (class_1309 mob : level.method_18198(net.minecraft.class_5575.method_31795(class_1309.class),
                            ent -> !(ent instanceof class_1657))) {
                        LetterStats.syncArmorModifiers(mob);
                    }
                }
            }

            // 光灵发光同步 / 生物消失诅咒零 UUID 绑定 / 掉落物定时清理
            LetterEntityEffects.tick(server);

            if (pendingDamages.isEmpty()) return;

            int intervalTicks = Math.max(1, (int) (ModConfig.getInstance().magicConversion.intervalSeconds * 20));

            List<UUID> toRemove = new ArrayList<>();
            for (Map.Entry<UUID, ConversionDamageState> entry : new ArrayList<>(pendingDamages.entrySet())) {
                UUID victimId = entry.getKey();
                ConversionDamageState state = entry.getValue();
                if (state.pendingByType.isEmpty()) {
                    toRemove.add(victimId);
                    continue;
                }
                if (state.countdown > 0) {
                    state.countdown--;
                    continue;
                }
                class_1309 living = findLivingEntity(server, victimId);
                if (living == null) {
                    state.staleTicks++;
                    if (state.staleTicks >= MAX_STALE_TICKS) {
                        toRemove.add(victimId);
                    } else {
                        state.countdown = 1;
                    }
                    continue;
                }
                PendingEntry pending = pickLargest(state);
                if (pending == null) {
                    toRemove.add(victimId);
                    continue;
                }
                applyConversionDamage(living, pending);

                if (state.pendingByType.isEmpty()) {
                    toRemove.add(victimId);
                } else {
                    state.countdown = intervalTicks;
                }
            }
            for (UUID uuid : toRemove) {
                pendingDamages.remove(uuid);
            }
        });
    }

    /**
     * 抗性提升：受害者携带的手札按“原版抗性提升药水”逻辑减免伤害
     * （减免比例 = 等级 × 每级增长，最终取 min(减免, 服务器配置上限)）。
     * 功能开关或减免为 0 时原样返回。
     */
    public static float applyResistanceReduction(class_1309 victim, float amount) {
        if (amount <= 0) return amount;
        ModConfig config = ModConfig.getInstance();
        if (!config.letterResistance.enabled) return amount;
        double reduction = LetterStats.effectiveResistance(victim, victim.method_37908());
        if (reduction <= 0) return amount;
        reduction = Math.min(reduction, config.letterResistance.limit);
        return (float) (amount * (1.0 - reduction));
    }

    public static boolean isConversionInProgress(class_1309 entity) {
        UUID current = CONVERSION_IN_PROGRESS.get();
        return current != null && current.equals(entity.method_5667());
    }

    public static boolean isLetterBoosted(class_1282 source) {
        if (source.method_49708(USEFULMAGIC_MAGIC)) return true;
        Optional<class_5321<class_8110>> keyOpt = source.method_48793().method_40230();
        if (keyOpt.isEmpty()) return false;
        return ModConfig.getInstance().getDefaultBonusDamageTypes().contains(keyOpt.get().method_29177());
    }

    /**
     * 是否应对本次伤害进行手札增益：
     * 1) 命中可增益伤害类型（玩家行为），或
     * 2) 攻击者为“生物”（非玩家 LivingEntity）且其主副手/装备持有生效手札时就对其所有伤害增益，
     *    不再要求伤害类型匹配（需求：生物持有手札时对所有产生的伤害进行增益）。
     */
    public static boolean shouldApplyLetterBoost(class_1282 source) {
        if (isLetterBoosted(source)) return true;
        class_1297 attacker = source.method_5529();
        if (attacker instanceof class_1309 holder && !(holder instanceof class_1657)) {
            return hasEffectiveLetter(holder);
        }
        return false;
    }

    private static boolean hasEffectiveLetter(class_1309 holder) {
        if (holder == null) return false;
        return !collectEffectiveLetters(holder, holder.method_37908()).isEmpty();
    }

    public static boolean isBlacklistedEntity(class_1309 victim) {
        class_2960 entityKey = class_1299.method_5890(victim.method_5864());
        return ModConfig.getInstance().getBlacklistEntityNames().contains(entityKey);
    }

    public static float onUsefulMagicHurtHealing(class_1309 victim, class_1282 source, float originalDamage) {
        class_1297 attacker = source.method_5529();
        if (!(attacker instanceof class_1309 holder)) return originalDamage;

        double multiplier = computeDirectMultiplier(holder, victim.method_37908());
        if (multiplier > 0) {
            return originalDamage * (1.0f + (float) multiplier);
        }
        return originalDamage;
    }

    public static boolean onUsefulMagicIncomingDamage(class_1309 victim, class_1282 source, float amount) {
        class_1297 attacker = source.method_5529();
        if (!(attacker instanceof class_1309 holder)) return false;

        if (amount <= 0.0F) return false;
        if (isBlacklistedEntity(victim)) return false;

        var groups = buildConversionGroups(holder, victim.method_37908());
        if (groups.isEmpty()) return false;

        class_2960 sourceTypeLoc = source.method_48793().method_40230().map(key -> key.method_29177()).orElse(null);

        ConversionDamageState state = pendingDamages.get(victim.method_5667());
        if (state == null) {
            if (pendingDamages.size() >= MAX_PENDING_VICTIMS) {
                return false;
            }
            state = new ConversionDamageState();
            state.countdown = Math.max(1, (int) (ModConfig.getInstance().magicConversion.intervalSeconds * 20));
            pendingDamages.put(victim.method_5667(), state);
        }

        for (var g : groups) {
            if (g.multiplier <= 0) continue;
            if (USEFULMAGIC_MAGIC.method_29177().equals(g.damageType)) continue;
            if (sourceTypeLoc != null && sourceTypeLoc.equals(g.damageType)) continue;
            float convAmount = amount * (float) g.multiplier;
            if (convAmount <= 0) continue;
            class_5321<class_8110> key = class_5321.method_29179(class_7924.field_42534, g.damageType);
            PendingEntry existing = state.pendingByType.get(key);
            if (existing == null) {
                if (state.pendingByType.size() >= MAX_PENDING_TYPES_PER_VICTIM) {
                    continue;
                }
                state.pendingByType.put(key, new PendingEntry(key, convAmount, source.method_5526(), source.method_5529()));
            } else {
                existing.amount += convAmount;
                existing.directEntity = source.method_5526();
                existing.sourceEntity = source.method_5529();
            }
        }
        return false;
    }

    private static class_1309 findLivingEntity(MinecraftServer server, UUID uuid) {
        for (class_3218 serverLevel : server.method_3738()) {
            class_1297 e = serverLevel.method_14190(uuid);
            if (e instanceof class_1309 le && le.method_5805()) {
                return le;
            }
        }
        return null;
    }

    private static PendingEntry pickLargest(ConversionDamageState state) {
        PendingEntry largest = null;
        for (PendingEntry entry : state.pendingByType.values()) {
            if (largest == null || entry.amount > largest.amount) {
                largest = entry;
            }
        }
        if (largest != null) {
            state.pendingByType.remove(largest.damageType);
        }
        return largest;
    }

    private static void applyConversionDamage(class_1309 living, PendingEntry pending) {
        var holderOpt = living.method_37908().method_30349()
                .method_30530(class_7924.field_42534)
                .method_40264(pending.damageType);
        if (holderOpt.isEmpty()) return;
        class_1282 convSource = new class_1282(holderOpt.get(), pending.directEntity, pending.sourceEntity);
        CONVERSION_IN_PROGRESS.set(living.method_5667());
        try {
            int savedInvuln = living.field_6008;
            living.field_6008 = 0;
            living.method_5643(convSource, pending.amount);
            living.field_6008 = savedInvuln;
        } finally {
            CONVERSION_IN_PROGRESS.remove();
        }
    }

    public static void onXpGained(class_1657 player, int amount) {
        if (amount <= 0) return;
        scanEntitySlots(player, stack -> {
            if (stack.method_31574(ModItems.EXPERIENCE_MAGIC_LETTER.get())) {
                ExperienceMagicLetterItem.addExperience(stack, amount);
            }
        });
    }

    public static void onFishCaught(class_1657 player) {
        if (player.method_37908().field_9236) return;
        scanEntitySlots(player, stack -> {
            if (stack.method_31574(ModItems.FISHING_MAGIC_LETTER.get())) {
                FishingMagicLetterItem.addFish(stack);
            }
        });
    }

    public static void onTreasureOpened(class_1657 player) {
        if (player.method_37908().field_9236) return;
        scanEntitySlots(player, stack -> {
            if (stack.method_31574(ModItems.TREASURE_MAGIC_LETTER.get())) {
                TreasureMagicLetterItem.addOpen(stack);
            }
        });
    }

    /** 坚韧魔法手札：实体（玩家或生物）承受的伤害累计。 */
    public static void onEntityDamageTaken(class_1309 entity, float amount) {
        if (entity.method_37908().field_9236 || amount <= 0) return;
        scanEntitySlots(entity, stack -> {
            if (stack.method_31574(ModItems.TENACITY_MAGIC_LETTER.get())) {
                TenacityMagicLetterItem.addDamage(stack, amount);
            }
        });
    }

    public static void onRaidVictory(class_1657 player) {
        if (player.method_37908().field_9236) return;
        scanEntitySlots(player, stack -> {
            if (stack.method_31574(ModItems.HERO_MAGIC_LETTER.get())) {
                HeroMagicLetterItem.addVictory(stack);
            }
        });
    }

    private static void tickTravelDistances(MinecraftServer server) {
        for (net.minecraft.class_3222 player : server.method_3760().method_14571()) {
            class_243 pos = player.method_19538();
            class_243 prev = lastTravelPos.get(player.method_5667());
            if (prev != null) {
                double dx = pos.field_1352 - prev.field_1352;
                double dz = pos.field_1350 - prev.field_1350;
                double dy = pos.field_1351 - prev.field_1351;
                double walk = 0;
                double fly = 0;
                if (player.method_31549().field_7479 || player.method_6128()) {
                    fly = Math.sqrt(dx * dx + dy * dy + dz * dz);
                } else {
                    walk = Math.sqrt(dx * dx + dz * dz);
                }
                walk = Math.min(walk, MAX_TRAVEL_PER_TICK * TRAVEL_POLL_INTERVAL);
                fly = Math.min(fly, MAX_TRAVEL_PER_TICK * TRAVEL_POLL_INTERVAL);
                if (walk > 0.001 || fly > 0.001) {
                    final double w = walk;
                    final double f = fly;
                    scanEntitySlots(player, stack -> {
                        if (stack.method_31574(ModItems.TRAVEL_MAGIC_LETTER.get())) {
                            TravelMagicLetterItem.addDistance(stack, w, f);
                        }
                    });
                }
            }
            lastTravelPos.put(player.method_5667(), pos);
        }
        if (lastTravelPos.size() > 1000) {
            lastTravelPos.clear();
        }
    }

    public static boolean shouldProtectItemDrop(class_1542 itemEntity, class_1282 source) {
        return isOurLetter(itemEntity.method_6983());
    }

    public static boolean isOurLetter(class_1799 stack) {
        return isOurModItem(stack);
    }

    public static boolean isOurModItem(class_1799 stack) {
        return stack.method_7909() instanceof MagicLetterItem || stack.method_7909() instanceof LetterBinderItem;
    }

    private static boolean isForeignBound(class_1657 player, class_1799 stack) {
        if (ModConfig.getInstance().letterBinding.uuidWhitelist.contains(player.method_5667().toString())) {
            return false; // 弹出白名单：该玩家可持有任意玩家 ID 绑定的手札/合订本而不弹出
        }
        Optional<UUID> bound = stack.method_57824(ModDataComponents.BOUND_PLAYER);
        return bound != null && bound.isPresent() && !bound.get().equals(player.method_5667());
    }

    private static void ejectForeignBoundLetters(MinecraftServer server) {
        for (net.minecraft.class_3222 player : server.method_3760().method_14571()) {
            class_1937 level = player.method_37908();
            if (level.field_9236) continue;
            var inv = player.method_31548();
            for (int i = 0; i < inv.field_7547.size(); i++) tryEjectForeign(level, inv.field_7547, i, player);
            for (int i = 0; i < inv.field_7548.size(); i++) tryEjectForeign(level, inv.field_7548, i, player);
            for (int i = 0; i < inv.field_7544.size(); i++) tryEjectForeign(level, inv.field_7544, i, player);
            List<class_1799> invStacks = new ArrayList<>();
            invStacks.addAll(inv.field_7547);
            invStacks.addAll(inv.field_7548);
            invStacks.addAll(inv.field_7544);
            for (class_1799 stack : invStacks) {
                ejectForeignInner(level, player, stack);
                if (stack.method_7909() instanceof LetterBinderItem) LetterBinderItem.ensureIcon(stack);
            }
            CuriosIntegration.ejectStacksWhere(player,
                    stack -> isOurModItem(stack) && isForeignBound(player, stack),
                    copy -> dropProtected(level, player, copy));
            for (class_1799 stack : CuriosIntegration.getCuriosStacks(player)) {
                ejectForeignInner(level, player, stack);
                if (stack.method_7909() instanceof LetterBinderItem) LetterBinderItem.ensureIcon(stack);
            }
            AccessoriesIntegration.ejectStacksWhere(player,
                    stack -> isOurModItem(stack) && isForeignBound(player, stack),
                    copy -> dropProtected(level, player, copy));
            AccessoriesIntegration.mutateStacksWhere(player,
                    stack -> stack.method_7909() instanceof LetterBinderItem,
                    stack -> {
                        ejectForeignInner(level, player, stack);
                        LetterBinderItem.ensureIcon(stack);
                    });
        }
    }

    private static void tryEjectForeign(class_1937 level, java.util.List<class_1799> container, int index, class_1657 player) {
        class_1799 stack = container.get(index);
        if (stack.method_7960()) return;
        if (!isOurModItem(stack)) return;
        if (!isForeignBound(player, stack)) return;
        class_1799 dropStack = stack.method_7972();
        container.set(index, class_1799.field_8037);
        dropProtected(level, player, dropStack);
    }

    private static void ejectForeignInner(class_1937 level, class_1657 player, class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof LetterBinderItem)) return;
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        if (contents.method_57429()) return;
        List<class_1799> keep = new ArrayList<>();
        boolean changed = false;
        for (class_1799 inner : contents.method_59708()) {
            if (inner.method_7960()) continue;
            if (isOurModItem(inner) && isForeignBound(player, inner)) {
                dropProtected(level, player, inner.method_7972());
                changed = true;
            } else {
                keep.add(inner.method_7972());
            }
        }
        if (changed) {
            stack.method_57379(class_9334.field_49650, new class_9276(keep));
            LetterBinderItem.ensureIcon(stack);
        }
    }

    private static void dropProtected(class_1937 level, class_1657 player, class_1799 dropStack) {
        class_1542 drop = new class_1542(level,
                player.method_23317(), player.method_5829().method_17940() > 0 ? player.method_23318() + 1.0 : player.method_23318() + 0.5, player.method_23321(),
                dropStack);
        level.method_8649(drop);
    }

    /**
     * 扫描实体携带的手札槽位：玩家含背包/盔甲/副手/饰品（Curios + Accessories），
     * 生物含手持/盔甲/饰品。用于让生物装备的手札同样对护甲/韧性/抗性/伤害/光灵生效。
     */
    private static void scanEntitySlots(class_1309 entity, java.util.function.Consumer<class_1799> consumer) {
        if (entity instanceof class_1657 player) {
            var inv = player.method_31548();
            for (var stack : inv.field_7547) scanStack(entity, stack, consumer);
            for (var stack : inv.field_7548) scanStack(entity, stack, consumer);
            for (var stack : inv.field_7544) scanStack(entity, stack, consumer);
        } else {
            for (var stack : entity.method_5661()) scanStack(entity, stack, consumer);
            for (var stack : entity.method_5877()) scanStack(entity, stack, consumer);
        }
        for (var stack : CuriosIntegration.getCuriosStacks(entity)) scanStack(entity, stack, consumer);
        for (var stack : AccessoriesIntegration.getAccessoriesStacks(entity)) scanStack(entity, stack, consumer);
    }

    private static void scanStack(class_1309 entity, class_1799 stack, java.util.function.Consumer<class_1799> consumer) {
        if (stack.method_7960()) return;
        consumer.accept(stack);
        if (stack.method_7909() instanceof LetterBinderItem) {
            class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
            for (class_1799 inner : contents.method_59708()) {
                if (!inner.method_7960()) {
                    consumer.accept(inner);
                }
            }
        }
    }

    private static double getMultiplierFromStack(class_1799 stack, class_1937 level) {
        if (stack.method_7960()) return 0;
        var item = stack.method_7909();
        if (item instanceof TimeMagicLetterItem) {
            return TimeMagicLetterItem.getMultiplier(level);
        }
        if (item instanceof MagicLetterItem ml) {
            return ml.getMultiplier(stack);
        }
        return 0;
    }

    private static List<LetterInfo> collectLetters(class_1309 holder, class_1937 level) {
        List<LetterInfo> result = new ArrayList<>();
        boolean dedup = !ModConfig.getInstance().stackingRules.allowSameLetters;
        Set<String> seen = new HashSet<>();
        scanEntitySlots(holder, stack -> {
            double mult = getMultiplierFromStack(stack, level);
            if (mult <= 0) return;
            Optional<UUID> bound = stack.method_57824(ModDataComponents.BOUND_PLAYER);
            if (bound != null && bound.isPresent() && !bound.get().equals(holder.method_5667())) {
                return;
            }
            class_2960 type = ModEnchantments.getEffectiveDamageType(stack);
            boolean enchanted = ModEnchantments.hasMagicConversion(stack);
            if (dedup) {
                String key = stack.method_7909() + "|" + mult + "|" + type + "|" + enchanted;
                if (!seen.add(key)) return;
            }
            result.add(new LetterInfo(mult, type, enchanted));
        });
        return result;
    }

    private static List<LetterInfo> collectEffectiveLetters(class_1309 holder, class_1937 level) {
        List<LetterInfo> letters = collectLetters(holder, level);
        if (letters.isEmpty()) return letters;
        if (!ModConfig.getInstance().stackingRules.allowMultipleLetters) {
            LetterInfo best = null;
            for (LetterInfo info : letters) {
                if (best == null || info.multiplier > best.multiplier) {
                    best = info;
                }
            }
            return best == null ? List.of() : List.of(best);
        }
        return letters;
    }

    private static class LetterInfo {
        final double multiplier;
        final class_2960 damageType;
        final boolean enchanted;

        LetterInfo(double multiplier, class_2960 damageType, boolean enchanted) {
            this.multiplier = multiplier;
            this.damageType = damageType;
            this.enchanted = enchanted;
        }
    }

    private static class TypeGroup {
        final class_2960 damageType;
        double multiplier;

        TypeGroup(class_2960 damageType, double multiplier) {
            this.damageType = damageType;
            this.multiplier = multiplier;
        }
    }

    private static double computeDirectMultiplier(class_1309 holder, class_1937 level) {
        double total = 0;
        for (LetterInfo info : collectEffectiveLetters(holder, level)) {
            if (info.enchanted) continue;
            total += info.multiplier;
        }
        return total;
    }

    private static List<TypeGroup> buildConversionGroups(class_1309 holder, class_1937 level) {
        Map<class_2960, List<Double>> byType = new LinkedHashMap<>();
        for (LetterInfo info : collectEffectiveLetters(holder, level)) {
            if (!info.enchanted) continue;
            byType.computeIfAbsent(info.damageType, k -> new ArrayList<>()).add(info.multiplier);
        }
        List<TypeGroup> groups = new ArrayList<>();
        for (var entry : byType.entrySet()) {
            double typeTotal = entry.getValue().stream().mapToDouble(Double::doubleValue).sum();
            groups.add(new TypeGroup(entry.getKey(), typeTotal));
        }
        return groups;
    }
}
