package cn.autoforged.enchanter_letter.enchantment;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9304;

public class ModEnchantments {
    public static final class_5321<class_1887> MAGIC_CONVERSION = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "magic_conversion"));

    /** 光灵：持有者（玩家/生物）发光，颜色由 NBT/组件 glow_color 控制。 */
    public static final class_5321<class_1887> GLOWING = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "glowing"));

    /** 魔法绑定：死亡不掉落（与消失诅咒排斥，同时存在时魔法绑定失效）。 */
    public static final class_5321<class_1887> MAGIC_BINDING = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "magic_binding"));

    /** 原版消失诅咒（本模组物品可附魔，玩家/生物持有者死亡移除）。 */
    public static final class_5321<class_1887> VANISHING_CURSE = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60656("vanishing_curse"));

    public static final String USEFULMAGIC_MAGIC = "usefulmagic:magic";

    public static boolean hasMagicConversion(class_1799 stack) {
        return hasEnchantment(stack, MAGIC_CONVERSION);
    }

    public static boolean hasGlowing(class_1799 stack) {
        return hasEnchantment(stack, GLOWING);
    }

    public static boolean hasMagicBinding(class_1799 stack) {
        return hasEnchantment(stack, MAGIC_BINDING);
    }

    public static boolean hasVanishing(class_1799 stack) {
        return hasEnchantment(stack, VANISHING_CURSE);
    }

    /** 魔法绑定与消失诅咒同时存在时，魔法绑定失效（按消失诅咒处理）。 */
    public static boolean hasEffectiveMagicBinding(class_1799 stack) {
        return hasMagicBinding(stack) && !hasVanishing(stack);
    }

    private static boolean hasEnchantment(class_1799 stack, class_5321<class_1887> key) {
        if (stack.method_7960()) return false;
        class_9304 enchantments = stack.method_58657();
        if (enchantments.method_57543()) return false;
        return enchantments.method_57534().stream().anyMatch(holder -> holder.method_40225(key));
    }

    /** 读取光灵颜色（0xRRGGBB）；未设置或 0 返回默认白色 0xFFFFFF。 */
    public static int getGlowColorOrDefault(class_1799 stack) {
        int color = stack.method_57825(ModDataComponents.GLOW_COLOR, 0);
        return color == 0 ? 0xFFFFFF : color;
    }

    /**
     * 获取手札实际生效的伤害类型。
     * 有 魔法转化 附魔时：读取组件中的 conversion_damage_type，
     *   若为空或无效则默认 usefulmagic:magic。
     * 无 魔法转化 附魔时：忽略组件，始终返回 usefulmagic:magic。
     */
    public static class_2960 getEffectiveDamageType(class_1799 stack) {
        if (!hasMagicConversion(stack)) {
            return class_2960.method_60654(USEFULMAGIC_MAGIC);
        }
        String nbtType = stack.method_57825(ModDataComponents.CONVERSION_DAMAGE_TYPE, "");
        if (nbtType.isEmpty()) {
            return class_2960.method_60654(USEFULMAGIC_MAGIC);
        }
        class_2960 parsed = class_2960.method_12829(nbtType);
        return parsed != null ? parsed : class_2960.method_60654(USEFULMAGIC_MAGIC);
    }

    public static String getConversionDamageTypeOrDefault(class_1799 stack) {
        String nbtType = stack.method_57825(ModDataComponents.CONVERSION_DAMAGE_TYPE, "");
        return nbtType.isEmpty() ? USEFULMAGIC_MAGIC : nbtType;
    }

    public static boolean isValidDamageTypeString(String id) {
        if (id == null || id.isEmpty()) return false;
        class_2960 parsed = class_2960.method_12829(id);
        return parsed != null;
    }

    /**
     * 校验 damageType 字符串是否对应注册表中已注册的伤害类型。
     * 用于命令端校验，客户端 tab 补全由命令参数自动提供。
     */
    public static boolean isValidDamageType(class_7225.class_7874 registries, class_2960 id) {
        if (USEFULMAGIC_MAGIC.equals(id.toString())) return true;
        return registries.method_46762(class_7924.field_42534)
                .method_46746(class_5321.method_29179(class_7924.field_42534, id)).isPresent();
    }
}
