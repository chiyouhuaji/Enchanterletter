package cn.autoforged.enchanter_letter.enchantment;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEnchantments {
    public static final String USEFULMAGIC_MAGIC = "usefulmagic:magic";

    /** 魔法转化附魔（1.20.1 代码注册；构造器为 protected，使用匿名子类）。 */
    public static class_1887 MAGIC_CONVERSION;

    /** 光灵：持有者（玩家/生物）发光，颜色由 NBT glow_color 控制。允许本模组所有手札/合订本。 */
    public static class_1887 GLOWING;

    /** 魔法绑定：死亡不掉落（与消失诅咒排斥，同时存在时魔法绑定失效）。允许任意物品。 */
    public static class_1887 MAGIC_BINDING;

    public static void register() {
        MAGIC_CONVERSION = class_2378.method_10230(class_7923.field_41176,
                new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "magic_conversion"),
                new class_1887(class_1887.class_1888.field_9087, class_1886.field_9074,
                        new class_1304[]{class_1304.field_6173, class_1304.field_6171}) {
                    /**
                     * 1.20.1 移植：附魔台/铁砧/指令均通过 canEnchant 判定可附魔物品。
                     * 等效 1.21.1 数据包附魔的 supported_items 标签
                     * #enchanter_letter:magic_conversion_enchantable（经验/杀戮/阶段 1-10 手札），
                     * 与 1.21.1 完全一致，否则手札无法附上魔法转化附魔。
                     */
                    @Override
                    public boolean method_8192(class_1799 stack) {
                        net.minecraft.class_1792 item = stack.method_7909();
                        return item == cn.autoforged.enchanter_letter.item.ModItems.EXPERIENCE_MAGIC_LETTER.get()
                                || item == cn.autoforged.enchanter_letter.item.ModItems.KILL_MAGIC_LETTER.get()
                                || item instanceof cn.autoforged.enchanter_letter.item.StageMagicLetterItem;
                    }
                });
        GLOWING = class_2378.method_10230(class_7923.field_41176,
                new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "glowing"),
                new class_1887(class_1887.class_1888.field_9087, class_1886.field_9082,
                        new class_1304[]{class_1304.field_6173, class_1304.field_6171}) {
                    @Override
                    public boolean method_8192(class_1799 stack) {
                        net.minecraft.class_1792 item = stack.method_7909();
                        return item instanceof cn.autoforged.enchanter_letter.item.MagicLetterItem
                                || item instanceof cn.autoforged.enchanter_letter.item.LetterBinderItem;
                    }
                });
        MAGIC_BINDING = class_2378.method_10230(class_7923.field_41176,
                new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "magic_binding"),
                new class_1887(class_1887.class_1888.field_9087, class_1886.field_9082,
                        new class_1304[]{class_1304.field_6173, class_1304.field_6171}) {
                    @Override
                    public boolean method_8192(class_1799 stack) {
                        if (stack.method_7960()) return false;
                        net.minecraft.class_1792 item = stack.method_7909();
                        if (item instanceof cn.autoforged.enchanter_letter.item.MagicLetterItem
                                || item instanceof cn.autoforged.enchanter_letter.item.LetterBinderItem) {
                            return true;
                        }
                        // 已注册到饰品模组（Curios / Accessories）物品标签
                        try {
                            return stack.method_40133().anyMatch(tag -> {
                                String ns = tag.comp_327().method_12836();
                                return "curios".equals(ns) || "accessories".equals(ns);
                            });
                        } catch (Exception ignored) {
                            return false;
                        }
                    }
                });
    }

    public static boolean hasMagicConversion(class_1799 stack) {
        if (stack.method_7960() || MAGIC_CONVERSION == null) return false;
        return net.minecraft.class_1890.method_8225(MAGIC_CONVERSION, stack) > 0;
    }

    public static boolean hasGlowing(class_1799 stack) {
        if (stack.method_7960() || GLOWING == null) return false;
        return net.minecraft.class_1890.method_8225(GLOWING, stack) > 0;
    }

    public static boolean hasMagicBinding(class_1799 stack) {
        if (stack.method_7960() || MAGIC_BINDING == null) return false;
        return net.minecraft.class_1890.method_8225(MAGIC_BINDING, stack) > 0;
    }

    /** 原版消失诅咒（本模组物品可附魔，玩家/生物持有者死亡移除）。 */
    public static boolean hasVanishing(class_1799 stack) {
        if (stack.method_7960()) return false;
        return net.minecraft.class_1890.method_8225(
                net.minecraft.class_1893.field_9109, stack) > 0;
    }

    /** 魔法绑定与消失诅咒同时存在时，魔法绑定失效（按消失诅咒处理）。 */
    public static boolean hasEffectiveMagicBinding(class_1799 stack) {
        return hasMagicBinding(stack) && !hasVanishing(stack);
    }

    /** 读取光灵颜色（NBT 0xRRGGBB）；未设置或 0 返回默认白色 0xFFFFFF。 */
    public static int getGlowColorOrDefault(class_1799 stack) {
        int color = ModDataComponents.getInt(stack, ModDataComponents.GLOW_COLOR, 0);
        return color == 0 ? 0xFFFFFF : color;
    }

    public static class_2960 getEffectiveDamageType(class_1799 stack) {
        if (!hasMagicConversion(stack)) {
            return new class_2960(USEFULMAGIC_MAGIC);
        }
        String nbtType = ModDataComponents.getString(stack, ModDataComponents.CONVERSION_DAMAGE_TYPE, "");
        if (nbtType.isEmpty()) {
            return new class_2960(USEFULMAGIC_MAGIC);
        }
        class_2960 parsed = class_2960.method_12829(nbtType);
        return parsed != null ? parsed : new class_2960(USEFULMAGIC_MAGIC);
    }

    public static String getConversionDamageTypeOrDefault(class_1799 stack) {
        String nbtType = ModDataComponents.getString(stack, ModDataComponents.CONVERSION_DAMAGE_TYPE, "");
        return nbtType.isEmpty() ? USEFULMAGIC_MAGIC : nbtType;
    }

    public static boolean isValidDamageTypeString(String id) {
        if (id == null || id.isEmpty()) return false;
        return class_2960.method_12829(id) != null;
    }

    public static boolean isValidDamageType(class_7225.class_7874 registries, class_2960 id) {
        if (USEFULMAGIC_MAGIC.equals(id.toString())) return true;
        return registries.method_46762(class_7924.field_42534)
                .method_46746(class_5321.method_29179(class_7924.field_42534, id)).isPresent();
    }
}
