package cn.autoforged.enchanter_letter.screen;

import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import cn.autoforged.enchanter_letter.network.ConversionDamageTypePayload;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;

public class ConversionDamageTypeScreen extends class_437 {
    private static final int INPUT_WIDTH = 200;
    private final class_1799 stack;
    private class_342 input;

    public ConversionDamageTypeScreen(class_1799 stack) {
        super(class_2561.method_43471("screen." + UsefulMagicEnchanterLetterMod.MOD_ID + ".conversion_damage_type"));
        this.stack = stack;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        input = new class_342(this.field_22793, centerX - INPUT_WIDTH / 2, centerY - 10, INPUT_WIDTH, 20,
                class_2561.method_43471("screen." + UsefulMagicEnchanterLetterMod.MOD_ID + ".damage_type_input"));
        input.method_1880(128);
        input.method_1890(s -> s.isEmpty() || s.codePoints().allMatch(c -> {
            if (c == ':') return true;
            if (Character.isLetterOrDigit(c)) return true;
            return c == '_' || c == '-';
        }));
        input.method_1852(ModEnchantments.getConversionDamageTypeOrDefault(stack));
        method_37063(input);

        method_37063(class_4185.method_46430(class_5244.field_24334, btn -> {
            String value = input.method_1882();
            if (!ModEnchantments.isValidDamageTypeString(value)) return;
            ConversionDamageTypePayload.sendToServer(value);
            this.method_25419();
        }).method_46434(centerX - 50, centerY + 20, 100, 20).method_46431());

        method_37063(class_4185.method_46430(class_5244.field_24335, btn -> this.method_25419())
                .method_46434(centerX - 50, centerY + 50, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        super.method_25394(guiGraphics, mouseX, mouseY, delta);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 30, 0xFFFFFF);
        guiGraphics.method_27534(this.field_22793,
                class_2561.method_43471("screen." + UsefulMagicEnchanterLetterMod.MOD_ID + ".damage_type_hint"),
                this.field_22789 / 2, 50, 0xAAAAAA);
    }
}