package cn.autoforged.enchanter_letter.network;

import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.storage.LetterStorageClient;
import cn.autoforged.enchanter_letter.storage.LetterStorageManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.Optional;
import java.util.UUID;

/**
 * /letterstorage 相关网络包（Fabric 1.21.1 CustomPacketPayload）：
 * - Capture 包（C2S）：客户端在交互模式下空手左键实体时上报该实体 UUID；
 * - Mode 包（S2C）：服务端同步交互模式开关给客户端。
 */
public class LetterStoragePayloads {
    public record CapturePayload(Optional<UUID> entityId) implements class_8710 {
        public static final class_9154<CapturePayload> TYPE =
                new class_9154<>(class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "letterstorage_capture"));
        public static final class_9139<class_2540, CapturePayload> STREAM_CODEC =
                class_9139.method_56434(
                        class_9135.method_56382(class_4844.field_48453), CapturePayload::entityId,
                        CapturePayload::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public record ModePayload(boolean active) implements class_8710 {
        public static final class_9154<ModePayload> TYPE =
                new class_9154<>(class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "letterstorage_mode"));
        public static final class_9139<class_2540, ModePayload> STREAM_CODEC =
                class_9139.method_56434(
                        class_9135.field_48547, ModePayload::active,
                        ModePayload::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(CapturePayload.TYPE, CapturePayload.STREAM_CODEC);
        PayloadTypeRegistry.playS2C().register(ModePayload.TYPE, ModePayload.STREAM_CODEC);

        ServerPlayNetworking.registerGlobalReceiver(CapturePayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                class_3222 player = context.player();
                Optional<UUID> entityId = payload.entityId();
                if (!LetterStorageManager.isCapturing(player)) return;
                if (entityId.isEmpty() || entityId.get().equals(player.method_5667())) return;
                UUID id = entityId.get();
                class_1297 target = findEntity(context.server(), id);
                if (target == null) return;
                LetterStorageManager.setCaptured(player, id);
                String name = target.method_5476().getString();
                player.method_43496(class_2561.method_43469(
                        "command.enchanter_letter.letterstorage.captured", name, id.toString()));
            });
        });
    }

    /** 客户端注册接收交互模式开关（在 ModClientEvents.register 中调用）。 */
    public static void registerClientReceiver() {
        ClientPlayNetworking.registerGlobalReceiver(ModePayload.TYPE, (payload, context) -> {
            context.client().execute(() -> LetterStorageClient.setActive(payload.active()));
        });
    }

    /** 客户端发送截取包。 */
    public static void sendCaptureToServer(UUID entityId) {
        ClientPlayNetworking.send(new CapturePayload(Optional.ofNullable(entityId)));
    }

    /** 服务端同步交互模式给指定玩家。 */
    public static void sendModeToClient(class_3222 player, boolean active) {
        ServerPlayNetworking.send(player, new ModePayload(active));
    }

    private static class_1297 findEntity(MinecraftServer server, UUID uuid) {
        for (class_3218 level : server.method_3738()) {
            class_1297 e = level.method_14190(uuid);
            if (e != null) return e;
        }
        return null;
    }
}
