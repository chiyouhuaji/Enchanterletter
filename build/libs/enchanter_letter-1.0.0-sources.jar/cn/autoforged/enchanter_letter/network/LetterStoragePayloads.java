package cn.autoforged.enchanter_letter.network;

import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.storage.LetterStorageClient;
import cn.autoforged.enchanter_letter.storage.LetterStorageManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * /letterstorage 相关网络包（Fabric 1.20.1，旧式 PacketByteBuf + 标识符）：
 * - Capture 包（C2S）：客户端在交互模式下空手左键实体时上报该实体 UUID；
 * - Mode 包（S2C）：服务端同步交互模式开关给客户端（用于客户端拦截空手左键）。
 */
public class LetterStoragePayloads {
    public static final class_2960 CAPTURE_PACKET_ID =
            new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "letterstorage_capture");
    public static final class_2960 MODE_PACKET_ID =
            new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "letterstorage_mode");

    public static void register() {
        // 服务端接收截取
        ServerPlayNetworking.registerGlobalReceiver(CAPTURE_PACKET_ID, (server, player, handler, buf, responseSender) -> {
            UUID entityId = buf.readBoolean() ? buf.method_10790() : null;
            server.execute(() -> {
                if (!LetterStorageManager.isCapturing(player)) return;
                if (entityId == null || entityId.equals(player.method_5667())) return;
                class_1297 target = findEntity(server, entityId);
                if (target == null) return;
                LetterStorageManager.setCaptured(player, entityId);
                String name = target.method_5476().getString();
                player.method_43496(class_2561.method_43469(
                        "command.enchanter_letter.letterstorage.captured", name, entityId.toString()));
            });
        });
    }

    /** 客户端注册接收交互模式开关（在 ModClientEvents.register 中调用）。 */
    public static void registerClientReceiver() {
        ClientPlayNetworking.registerGlobalReceiver(MODE_PACKET_ID, (client, handler, buf, responseSender) -> {
            boolean active = buf.readBoolean();
            client.execute(() -> LetterStorageClient.setActive(active));
        });
    }

    /** 客户端发送截取包。 */
    public static void sendCaptureToServer(UUID entityId) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(entityId != null);
        if (entityId != null) buf.method_10797(entityId);
        ClientPlayNetworking.send(CAPTURE_PACKET_ID, buf);
    }

    /** 服务端同步交互模式给指定玩家。 */
    public static void sendModeToClient(class_3222 player, boolean active) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(active);
        ServerPlayNetworking.send(player, MODE_PACKET_ID, buf);
    }

    private static class_1297 findEntity(MinecraftServer server, UUID uuid) {
        for (class_3218 level : server.method_3738()) {
            class_1297 e = level.method_14190(uuid);
            if (e != null) return e;
        }
        return null;
    }
}
