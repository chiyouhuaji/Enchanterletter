package cn.autoforged.enchanter_letter.network;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/** 1.20.1 移植：Fabric 旧式包（PacketByteBuf + 标识符）。 */
public class ConversionDamageTypePayload {
    public static final class_2960 PACKET_ID =
            new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "conversion_damage_type");

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(PACKET_ID, (server, player, handler, buf, responseSender) -> {
            String damageType = buf.method_10800(128);
            server.execute(() -> {
                var stack = player.method_6047();
                if (stack.method_7909() != class_1802.field_8598) return;
                if (!ModEnchantments.hasMagicConversion(stack)) return;
                if (!player.method_7337()) return;
                if (ModEnchantments.isValidDamageTypeString(damageType)) {
                    ModDataComponents.setString(stack, ModDataComponents.CONVERSION_DAMAGE_TYPE, damageType);
                }
            });
        });
    }

    /** 客户端发送（仅在客户端调用）。 */
    public static void sendToServer(String damageType) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10788(damageType, 128);
        ClientPlayNetworking.send(PACKET_ID, buf);
    }
}
