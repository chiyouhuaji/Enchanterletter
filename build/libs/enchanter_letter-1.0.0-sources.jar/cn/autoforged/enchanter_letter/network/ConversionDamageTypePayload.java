package cn.autoforged.enchanter_letter.network;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ConversionDamageTypePayload(String damageType) implements class_8710 {
    public static final class_8710.class_9154<ConversionDamageTypePayload> TYPE =
            new class_8710.class_9154<>(class_2960.method_60655(
                    UsefulMagicEnchanterLetterMod.MOD_ID, "conversion_damage_type"));
    public static final class_9139<class_2540, ConversionDamageTypePayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_9135.field_48554, ConversionDamageTypePayload::damageType,
                    ConversionDamageTypePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(TYPE, STREAM_CODEC);
        ServerPlayNetworking.registerGlobalReceiver(TYPE, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                var stack = player.method_6047();
                if (stack.method_7909() != class_1802.field_8598) return;
                if (!ModEnchantments.hasMagicConversion(stack)) return;
                if (!player.method_7337()) return;
                String damageType = payload.damageType();
                if (ModEnchantments.isValidDamageTypeString(damageType)) {
                    stack.method_57379(ModDataComponents.CONVERSION_DAMAGE_TYPE, damageType);
                }
            });
        });
    }

    /** 客户端发送（仅在客户端调用）。 */
    public static void sendToServer(String damageType) {
        ClientPlayNetworking.send(new ConversionDamageTypePayload(damageType));
    }
}
