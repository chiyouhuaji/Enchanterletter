package cn.autoforged.enchanter_letter;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;

/**
 * 1.20.1 移植：物品数据使用 NBT 标签存储（替代 1.21.1 的 DataComponents）。
 */
public class ModDataComponents {
    public static final String EXPERIENCE_PROGRESS = "experience_progress";
    public static final String KILL_COUNT = "kill_count";
    public static final String BOUND_PLAYER = "bound_player";
    public static final String CONVERSION_DAMAGE_TYPE = "conversion_damage_type";
    public static final String FISH_COUNT = "fish_count";
    public static final String WALK_DISTANCE = "walk_distance";
    public static final String FLY_DISTANCE = "fly_distance";
    public static final String TREASURE_OPENS = "treasure_opens";
    public static final String DAMAGE_TAKEN = "damage_taken";
    public static final String RAID_VICTORIES = "raid_victories";
    public static final String GLOW_COLOR = "glow_color";

    /** 定制手札：直接写入 NBT 的伤害倍率/护甲/韧性/抗性数值，不参与计数成长。 */
    public static final String CUSTOM_DAMAGE = "custom_damage";
    public static final String CUSTOM_ARMOR = "custom_armor";
    public static final String CUSTOM_TOUGHNESS = "custom_toughness";
    public static final String CUSTOM_RESISTANCE = "custom_resistance";

    public static double getDouble(class_1799 stack, String key, double def) {
        class_2487 tag = stack.method_7969();
        return tag != null && tag.method_10573(key, class_2520.field_33256) ? tag.method_10574(key) : def;
    }

    public static int getInt(class_1799 stack, String key, int def) {
        class_2487 tag = stack.method_7969();
        return tag != null && tag.method_10573(key, class_2520.field_33253) ? tag.method_10550(key) : def;
    }

    public static String getString(class_1799 stack, String key, String def) {
        class_2487 tag = stack.method_7969();
        return tag != null && tag.method_10573(key, class_2520.field_33258) ? tag.method_10558(key) : def;
    }

    public static Optional<UUID> getBoundPlayer(class_1799 stack) {
        class_2487 tag = stack.method_7969();
        if (tag != null && tag.method_10573(BOUND_PLAYER, class_2520.field_33258)) {
            try {
                return Optional.of(UUID.fromString(tag.method_10558(BOUND_PLAYER)));
            } catch (IllegalArgumentException ignored) {
                return Optional.empty();
            }
        }
        return Optional.empty();
    }

    public static void setDouble(class_1799 stack, String key, double value) {
        stack.method_7948().method_10549(key, value);
    }

    public static void setInt(class_1799 stack, String key, int value) {
        stack.method_7948().method_10569(key, value);
    }

    public static void setString(class_1799 stack, String key, String value) {
        stack.method_7948().method_10582(key, value);
    }

    public static void setBoundPlayer(class_1799 stack, UUID uuid) {
        stack.method_7948().method_10582(BOUND_PLAYER, uuid.toString());
    }

    public static void removeBoundPlayer(class_1799 stack) {
        if (stack.method_7985()) {
            stack.method_7969().method_10551(BOUND_PLAYER);
        }
    }
}
