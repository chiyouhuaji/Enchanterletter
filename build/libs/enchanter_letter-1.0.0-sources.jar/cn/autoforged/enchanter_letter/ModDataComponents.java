package cn.autoforged.enchanter_letter;

import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_5699;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

public class ModDataComponents {
    private static class_9331<Double> simpleDouble(String name) {
        return class_2378.method_10230(class_7923.field_49658,
                class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, name),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57882(class_9135.field_48553).method_57880());
    }

    private static class_9331<Integer> simpleInt(String name) {
        return class_2378.method_10230(class_7923.field_49658,
                class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, name),
                class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880());
    }

    private static class_9331<String> simpleString(String name) {
        return class_2378.method_10230(class_7923.field_49658,
                class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, name),
                class_9331.<String>method_57873().method_57881(Codec.STRING).method_57882(class_9135.field_48554).method_57880());
    }

    /** 强制在 onInitialize 阶段加载本类，避免注册表冻结后才初始化导致崩溃。 */
    public static void init() {
    }

    public static final class_9331<Double> EXPERIENCE_PROGRESS = simpleDouble("experience_progress");
    public static final class_9331<Integer> KILL_COUNT = simpleInt("kill_count");
    public static final class_9331<Optional<UUID>> BOUND_PLAYER = class_2378.method_10230(
            class_7923.field_49658,
            class_2960.method_60655(UsefulMagicEnchanterLetterMod.MOD_ID, "bound_player"),
            class_9331.<Optional<UUID>>method_57873()
                    .method_57881(class_5699.method_57155(class_4844.field_25122))
                    .method_57882(class_9135.method_56382(class_4844.field_48453))
                    .method_57880());
    public static final class_9331<String> CONVERSION_DAMAGE_TYPE = simpleString("conversion_damage_type");
    public static final class_9331<Integer> FISH_COUNT = simpleInt("fish_count");
    public static final class_9331<Double> WALK_DISTANCE = simpleDouble("walk_distance");
    public static final class_9331<Double> FLY_DISTANCE = simpleDouble("fly_distance");
    public static final class_9331<Integer> TREASURE_OPENS = simpleInt("treasure_opens");
    public static final class_9331<Double> DAMAGE_TAKEN = simpleDouble("damage_taken");
    public static final class_9331<Integer> RAID_VICTORIES = simpleInt("raid_victories");
    public static final class_9331<Integer> GLOW_COLOR = simpleInt("glow_color");

    /** 定制手札：直接写入物品的伤害倍率/护甲/韧性/抗性数值，不参与计数成长。 */
    public static final class_9331<Double> CUSTOM_DAMAGE = simpleDouble("custom_damage");
    public static final class_9331<Double> CUSTOM_ARMOR = simpleDouble("custom_armor");
    public static final class_9331<Double> CUSTOM_TOUGHNESS = simpleDouble("custom_toughness");
    public static final class_9331<Double> CUSTOM_RESISTANCE = simpleDouble("custom_resistance");
}
