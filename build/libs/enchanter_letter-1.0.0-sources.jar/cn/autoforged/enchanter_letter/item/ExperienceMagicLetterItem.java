package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class ExperienceMagicLetterItem extends MagicLetterItem {
    public ExperienceMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addExperience(class_1799 stack, double amount) {
        stack.method_57379(ModDataComponents.EXPERIENCE_PROGRESS, getExperience(stack) + amount);
    }

    public static double getExperience(class_1799 stack) {
        return stack.method_57825(ModDataComponents.EXPERIENCE_PROGRESS, 0.0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        double expPerLevel = ModConfig.getInstance().experienceLetter.expPerLevel;
        return (int) (getExperience(stack) / expPerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().experienceLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
