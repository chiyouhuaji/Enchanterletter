package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class KillMagicLetterItem extends MagicLetterItem {
    public KillMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addKill(class_1799 stack) {
        stack.method_57379(ModDataComponents.KILL_COUNT, getKills(stack) + 1);
    }

    public static int getKills(class_1799 stack) {
        return stack.method_57825(ModDataComponents.KILL_COUNT, 0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        int killsPerLevel = ModConfig.getInstance().killLetter.killsPerLevel;
        return getKills(stack) / killsPerLevel;
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().killLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
