package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class KillMagicLetterItem extends MagicLetterItem {
    public KillMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addKill(class_1799 stack) {
        int current = ModDataComponents.getInt(stack, ModDataComponents.KILL_COUNT, 0);
        ModDataComponents.setInt(stack, ModDataComponents.KILL_COUNT, current + 1);
    }

    public static int getKills(class_1799 stack) {
        return ModDataComponents.getInt(stack, ModDataComponents.KILL_COUNT, 0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        int killsPerLevel = ModConfig.getInstance().killLetter.killsPerLevel;
        return getKills(stack) / killsPerLevel;
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().killLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
