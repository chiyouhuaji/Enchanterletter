package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class ModItems {
    public static final List<Supplier<? extends class_1792>> ALL_LETTERS = new ArrayList<>();

    public static final Supplier<ExperienceMagicLetterItem> EXPERIENCE_MAGIC_LETTER =
            register("experience_magic_letter",
                    () -> new ExperienceMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<KillMagicLetterItem> KILL_MAGIC_LETTER =
            register("kill_magic_letter",
                    () -> new KillMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<FishingMagicLetterItem> FISHING_MAGIC_LETTER =
            register("fishing_magic_letter",
                    () -> new FishingMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<TravelMagicLetterItem> TRAVEL_MAGIC_LETTER =
            register("travel_magic_letter",
                    () -> new TravelMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<TreasureMagicLetterItem> TREASURE_MAGIC_LETTER =
            register("treasure_magic_letter",
                    () -> new TreasureMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<TimeMagicLetterItem> TIME_MAGIC_LETTER =
            register("time_magic_letter",
                    () -> new TimeMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<TenacityMagicLetterItem> TENACITY_MAGIC_LETTER =
            register("tenacity_magic_letter",
                    () -> new TenacityMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<HeroMagicLetterItem> HERO_MAGIC_LETTER =
            register("hero_magic_letter",
                    () -> new HeroMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<CustomMagicLetterItem> CUSTOM_MAGIC_LETTER =
            register("custom_magic_letter",
                    () -> new CustomMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<LetterBinderItem> LETTER_BINDER =
            register("letter_binder",
                    () -> new LetterBinderItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final Supplier<StageMagicLetterItem> STAGE_1_MAGIC_LETTER =
            register("stage_1_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8906).method_24359(), 1));

    public static final Supplier<StageMagicLetterItem> STAGE_2_MAGIC_LETTER =
            register("stage_2_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8906).method_24359(), 2));

    public static final Supplier<StageMagicLetterItem> STAGE_3_MAGIC_LETTER =
            register("stage_3_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8907).method_24359(), 3));

    public static final Supplier<StageMagicLetterItem> STAGE_4_MAGIC_LETTER =
            register("stage_4_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8907).method_24359(), 4));

    public static final Supplier<StageMagicLetterItem> STAGE_5_MAGIC_LETTER =
            register("stage_5_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8907).method_24359(), 5));

    public static final Supplier<StageMagicLetterItem> STAGE_6_MAGIC_LETTER =
            register("stage_6_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_24359(), 6));

    public static final Supplier<StageMagicLetterItem> STAGE_7_MAGIC_LETTER =
            register("stage_7_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_24359(), 7));

    public static final Supplier<StageMagicLetterItem> STAGE_8_MAGIC_LETTER =
            register("stage_8_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_24359(), 8));

    public static final Supplier<StageMagicLetterItem> STAGE_9_MAGIC_LETTER =
            register("stage_9_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359(), 9));

    public static final Supplier<StageMagicLetterItem> STAGE_10_MAGIC_LETTER =
            register("stage_10_magic_letter",
                    () -> new StageMagicLetterItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359(), 10));

    private static <T extends class_1792> Supplier<T> register(String name, Supplier<T> supplier) {
        T item = supplier.get();
        class_2378.method_10230(class_7923.field_41178,
                new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, name), item);
        Supplier<T> result = () -> item;
        ALL_LETTERS.add(result);
        return result;
    }

    public static final class_5321<class_1761> MAGIC_LETTERS_TAB_KEY =
            class_5321.method_29179(class_7924.field_44688,
                    new class_2960(UsefulMagicEnchanterLetterMod.MOD_ID, "magic_letters"));

    public static void registerItems() {
        class_2378.method_39197(class_7923.field_44687, MAGIC_LETTERS_TAB_KEY,
                FabricItemGroup.builder()
                        .method_47320(() -> {
                            // 标签页图标使用"合订本_有手札"贴图（CustomModelData=1 切换）
                            class_1799 iconStack = new class_1799(LETTER_BINDER.get());
                            iconStack.method_7948().method_10569("CustomModelData", 1);
                            return iconStack;
                        })
                        .method_47321(class_2561.method_43471("itemGroup." + UsefulMagicEnchanterLetterMod.MOD_ID))
                        .method_47317((params, output) -> {
                            output.method_45421(EXPERIENCE_MAGIC_LETTER.get());
                            output.method_45421(KILL_MAGIC_LETTER.get());
                            output.method_45421(FISHING_MAGIC_LETTER.get());
                            output.method_45421(TRAVEL_MAGIC_LETTER.get());
                            output.method_45421(TREASURE_MAGIC_LETTER.get());
                            output.method_45421(TIME_MAGIC_LETTER.get());
                            output.method_45421(TENACITY_MAGIC_LETTER.get());
                            output.method_45421(HERO_MAGIC_LETTER.get());
                            output.method_45421(CUSTOM_MAGIC_LETTER.get());
                            output.method_45421(LETTER_BINDER.get());
                            output.method_45421(STAGE_1_MAGIC_LETTER.get());
                            output.method_45421(STAGE_2_MAGIC_LETTER.get());
                            output.method_45421(STAGE_3_MAGIC_LETTER.get());
                            output.method_45421(STAGE_4_MAGIC_LETTER.get());
                            output.method_45421(STAGE_5_MAGIC_LETTER.get());
                            output.method_45421(STAGE_6_MAGIC_LETTER.get());
                            output.method_45421(STAGE_7_MAGIC_LETTER.get());
                            output.method_45421(STAGE_8_MAGIC_LETTER.get());
                            output.method_45421(STAGE_9_MAGIC_LETTER.get());
                            output.method_45421(STAGE_10_MAGIC_LETTER.get());
                        })
                        .method_47324());
    }
}
