package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import cn.autoforged.enchanter_letter.integration.AccessoriesIntegration;
import cn.autoforged.enchanter_letter.integration.CuriosIntegration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_9276;
import net.minecraft.class_9334;

/**
 * 手札的防御属性结算（护甲值、护甲韧性、抗性提升）。
 */
public class LetterStats {

    /** 单张手札的防御属性条目（HUD 逐条显示用）。 */
    public static class Entry {
        public final class_1799 stack;
        public final int level;
        public final double damageMultiplier;
        public final double armor;
        public final double toughness;
        public final double resistance;
        public final boolean enchanted;
        public final class_2960 damageType;

        public Entry(class_1799 stack, int level, double damageMultiplier, double armor,
                     double toughness, double resistance, boolean enchanted, class_2960 damageType) {
            this.stack = stack;
            this.level = level;
            this.damageMultiplier = damageMultiplier;
            this.armor = armor;
            this.toughness = toughness;
            this.resistance = resistance;
            this.enchanted = enchanted;
            this.damageType = damageType;
        }
    }

    private LetterStats() {
    }

    private static final class_2960 ARMOR_BONUS_ID =
            class_2960.method_60655("enchanter_letter", "armor_bonus");

    public static Entry of(class_1799 stack, class_1937 level) {
        return fromStack(stack, level);
    }

    public static void syncArmorModifiers(class_1657 player) {
        syncArmorModifiers((class_1309) player);
    }

    public static void syncArmorModifiers(class_1309 entity) {
        double[] bonus = armorToughnessBonus(entity, entity.method_37908());
        setModifier(entity, class_5134.field_23724, bonus[0]);
        setModifier(entity, class_5134.field_23725, bonus[1]);
    }

    private static void setModifier(class_1309 entity, class_6880<class_1320> attribute, double value) {
        class_1324 inst = entity.method_5996(attribute);
        if (inst == null) return;
        inst.method_6200(ARMOR_BONUS_ID);
        if (value > 0) {
            inst.method_26835(new class_1322(ARMOR_BONUS_ID,
                    value, class_1322.class_1323.field_6328));
        }
    }

    public static List<Entry> collectEntries(class_1309 player, class_1937 level) {
        List<Entry> result = new ArrayList<>();
        boolean dedup = !ModConfig.getInstance().stackingRules.allowSameLetters;
        Set<String> seen = new HashSet<>();
        scanAllSlots(player, stack -> {
            Entry entry = fromStack(stack, level);
            if (entry == null) return;
            if (entry.damageMultiplier <= 0 && entry.armor <= 0 && entry.toughness <= 0 && entry.resistance <= 0) {
                return;
            }
            Optional<UUID> bound = stack.method_57824(ModDataComponents.BOUND_PLAYER);
            if (bound != null && bound.isPresent() && !bound.get().equals(player.method_5667())) {
                return;
            }
            if (dedup) {
                String key = stack.method_7909() + "|" + entry.damageMultiplier + "|" + entry.damageType + "|" + entry.enchanted;
                if (!seen.add(key)) return;
            }
            result.add(entry);
        });
        return result;
    }

    public static double effectiveArmor(class_1309 player, class_1937 level) {
        List<Entry> entries = collectEntries(player, level);
        if (entries.isEmpty()) return 0;
        if (ModConfig.getInstance().stackingRules.allowMultipleLetters) {
            double total = 0;
            for (Entry e : entries) total += e.armor;
            return total;
        }
        double max = 0;
        for (Entry e : entries) max = Math.max(max, e.armor);
        return max;
    }

    public static double effectiveToughness(class_1309 player, class_1937 level) {
        List<Entry> entries = collectEntries(player, level);
        if (entries.isEmpty()) return 0;
        if (ModConfig.getInstance().stackingRules.allowMultipleLetters) {
            double total = 0;
            for (Entry e : entries) total += e.toughness;
            return total;
        }
        double max = 0;
        for (Entry e : entries) max = Math.max(max, e.toughness);
        return max;
    }

    public static double effectiveResistance(class_1309 player, class_1937 level) {
        List<Entry> entries = collectEntries(player, level);
        if (entries.isEmpty()) return 0;
        if (ModConfig.getInstance().stackingRules.allowMultipleLetters) {
            double total = 0;
            for (Entry e : entries) total += e.resistance;
            return total;
        }
        double max = 0;
        for (Entry e : entries) max = Math.max(max, e.resistance);
        return max;
    }

    public static double[] armorToughnessBonus(class_1309 player, class_1937 level) {
        return new double[]{effectiveArmor(player, level), effectiveToughness(player, level)};
    }

    private static Entry fromStack(class_1799 stack, class_1937 level) {
        if (stack.method_7960()) return null;
        class_1792 item = stack.method_7909();
        ModConfig config = ModConfig.getInstance();
        boolean enchanted = ModEnchantments.hasMagicConversion(stack);
        class_2960 type = ModEnchantments.getEffectiveDamageType(stack);

        if (item instanceof TimeMagicLetterItem time) {
            int lv = time.getLevel(stack, level);
            ModConfig.TimeLetterConfig cfg = config.timeLetter;
            return new Entry(stack, lv, TimeMagicLetterItem.getMultiplier(level),
                    lv * cfg.armorGrowthPerLevel, lv * cfg.toughnessGrowthPerLevel, lv * cfg.resistanceGrowthPerLevel,
                    enchanted, type);
        }
        if (item instanceof TravelMagicLetterItem) {
            ModConfig.TravelLetterConfig cfg = config.travelLetter;
            double walkLevels = Math.floor(TravelMagicLetterItem.getWalkDistance(stack) / cfg.walkDistancePerLevel);
            double flyLevels = Math.floor(TravelMagicLetterItem.getFlyDistance(stack) / cfg.flyDistancePerLevel);
            return new Entry(stack, (int) (walkLevels + flyLevels),
                    walkLevels * cfg.walkGrowthPerLevel + flyLevels * cfg.flyGrowthPerLevel,
                    walkLevels * cfg.armorGrowthPerLevel + flyLevels * cfg.armor2GrowthPerLevel,
                    walkLevels * cfg.toughnessGrowthPerLevel + flyLevels * cfg.toughness2GrowthPerLevel,
                    walkLevels * cfg.resistanceGrowthPerLevel + flyLevels * cfg.resistance2GrowthPerLevel,
                    enchanted, type);
        }
        if (item instanceof HeroMagicLetterItem hero) {
            int lv = hero.getLevel(stack);
            ModConfig.HeroLetterConfig cfg = config.heroLetter;
            boolean high = lv >= cfg.highLevelStart;
            return new Entry(stack, lv,
                    lv * (high ? cfg.growthHighLevels : cfg.growthLowLevels),
                    lv * (high ? cfg.armor2GrowthPerLevel : cfg.armorGrowthPerLevel),
                    lv * (high ? cfg.toughness2GrowthPerLevel : cfg.toughnessGrowthPerLevel),
                    lv * (high ? cfg.resistance2GrowthPerLevel : cfg.resistanceGrowthPerLevel),
                    enchanted, type);
        }
        if (item instanceof StageMagicLetterItem stage) {
            int lv = stage.getLevel(stack);
            ModConfig.StageLettersConfig cfg = config.stageLetters;
            return new Entry(stack, lv, stage.getMultiplier(stack),
                    stageValue(cfg.armorValues, lv, lv * 2.0),
                    stageValue(cfg.toughnessValues, lv, lv * 1.0),
                    stageValue(cfg.resistanceValues, lv, 0.0),
                    enchanted, type);
        }
        if (item instanceof ExperienceMagicLetterItem ml) return simple(stack, level, ml, config.experienceLetter.armorGrowthPerLevel, config.experienceLetter.toughnessGrowthPerLevel, config.experienceLetter.resistanceGrowthPerLevel, enchanted, type);
        if (item instanceof KillMagicLetterItem ml) return simple(stack, level, ml, config.killLetter.armorGrowthPerLevel, config.killLetter.toughnessGrowthPerLevel, config.killLetter.resistanceGrowthPerLevel, enchanted, type);
        if (item instanceof FishingMagicLetterItem ml) return simple(stack, level, ml, config.fishingLetter.armorGrowthPerLevel, config.fishingLetter.toughnessGrowthPerLevel, config.fishingLetter.resistanceGrowthPerLevel, enchanted, type);
        if (item instanceof TreasureMagicLetterItem ml) return simple(stack, level, ml, config.treasureLetter.armorGrowthPerLevel, config.treasureLetter.toughnessGrowthPerLevel, config.treasureLetter.resistanceGrowthPerLevel, enchanted, type);
        if (item instanceof TenacityMagicLetterItem ml) return simple(stack, level, ml, config.tenacityLetter.armorGrowthPerLevel, config.tenacityLetter.toughnessGrowthPerLevel, config.tenacityLetter.resistanceGrowthPerLevel, enchanted, type);
        if (item instanceof CustomMagicLetterItem custom) {
            return new Entry(stack, 0, custom.getMultiplier(stack),
                    CustomMagicLetterItem.getCustomArmor(stack),
                    CustomMagicLetterItem.getCustomToughness(stack),
                    CustomMagicLetterItem.getCustomResistance(stack),
                    enchanted, type);
        }
        return null;
    }

    private static double stageValue(List<Double> values, int stage, double fallback) {
        if (values == null || stage < 1 || stage > values.size()) return fallback;
        Double v = values.get(stage - 1);
        return v == null ? fallback : v;
    }

    private static Entry simple(class_1799 stack, class_1937 level, MagicLetterItem ml,
                                double armorGrowth, double toughnessGrowth, double resistanceGrowth,
                                boolean enchanted, class_2960 type) {
        int lv = ml.getLevel(stack, level);
        return new Entry(stack, lv, ml.getMultiplier(stack, level),
                lv * armorGrowth, lv * toughnessGrowth, lv * resistanceGrowth,
                enchanted, type);
    }

    private static void scanAllSlots(class_1309 entity, java.util.function.Consumer<class_1799> consumer) {
        if (entity instanceof class_1657 player) {
            var inv = player.method_31548();
            for (var stack : inv.field_7547) scanStack(entity, stack, consumer);
            for (var stack : inv.field_7548) scanStack(entity, stack, consumer);
            for (var stack : inv.field_7544) scanStack(entity, stack, consumer);
        } else {
            for (var stack : entity.method_5661()) scanStack(entity, stack, consumer);
            for (var stack : entity.method_5877()) scanStack(entity, stack, consumer);
        }
        for (var stack : CuriosIntegration.getCuriosStacks(entity)) scanStack(entity, stack, consumer);
        for (var stack : AccessoriesIntegration.getAccessoriesStacks(entity)) scanStack(entity, stack, consumer);
    }

    private static void scanStack(class_1309 entity, class_1799 stack, java.util.function.Consumer<class_1799> consumer) {
        if (stack.method_7960()) return;
        consumer.accept(stack);
        if (stack.method_7909() instanceof LetterBinderItem) {
            class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
            for (class_1799 inner : contents.method_59708()) {
                if (!inner.method_7960()) consumer.accept(inner);
            }
        }
    }
}
