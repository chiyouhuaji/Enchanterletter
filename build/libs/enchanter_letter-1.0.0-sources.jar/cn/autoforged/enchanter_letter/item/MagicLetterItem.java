package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;

public abstract class MagicLetterItem extends class_1792 {
    protected static final DecimalFormat PERCENT_FORMAT = new DecimalFormat("+#0.0%");
    protected static final DecimalFormat LEVEL_FORMAT = new DecimalFormat("#,###");
    protected static final DecimalFormat VALUE_FORMAT = new DecimalFormat("+#0.0#");

    public MagicLetterItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 level, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        super.method_7851(stack, level, tooltipComponents, tooltipFlag);
        int lvl = getLevel(stack, level);
        double multiplier = getMultiplier(stack, level);
        tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".level", LEVEL_FORMAT.format(lvl))
                .method_27692(class_124.field_1065));
                tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".magic_damage_bonus", PERCENT_FORMAT.format(multiplier))
                .method_27692(class_124.field_1061));
        // 防御属性：护甲值 / 护甲韧性（直接数值）、抗性提升（减免比例）
        LetterStats.Entry stats = LetterStats.of(stack, level);
        if (stats != null) {
            if (stats.armor > 0) {
                tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".armor_bonus", VALUE_FORMAT.format(stats.armor))
                        .method_27692(class_124.field_1054));
            }
            if (stats.toughness > 0) {
                tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".toughness_bonus", VALUE_FORMAT.format(stats.toughness))
                        .method_27692(class_124.field_1078));
            }
            if (stats.resistance > 0) {
                tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".resistance_bonus", PERCENT_FORMAT.format(stats.resistance))
                        .method_27692(class_124.field_1076));
            }
        }
        if (ModEnchantments.hasMagicConversion(stack)) {
            class_2960 effectiveType = ModEnchantments.getEffectiveDamageType(stack);
            tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".conversion_damage_type", effectiveType.toString())
                    .method_27692(class_124.field_1064));
        }
        // 非阶段/非定制手札：显示当前行为进度总计数（阶段手札与定制手札无计数值/无进度）
        if (!(this instanceof StageMagicLetterItem) && !(this instanceof CustomMagicLetterItem)) {
            String progress = getProgressRingText(stack, level);
            if (progress != null && !progress.isEmpty()) {
                tooltipComponents.add(class_2561.method_43470(progress).method_27692(class_124.field_1080));
            }
        }
        Optional<UUID> owner = ModDataComponents.getBoundPlayer(stack);
        if (owner.isPresent()) {
            String displayName;
            try {
                var mc = net.minecraft.class_310.method_1551();
                if (mc.method_1562() != null) {
                    var playerInfo = mc.method_1562().method_2871(owner.get());
                    if (playerInfo != null) {
                        displayName = playerInfo.method_2966().getName();
                    } else {
                        displayName = owner.get().toString();
                    }
                } else {
                    displayName = owner.get().toString();
                }
            } catch (Throwable e) {
                displayName = owner.get().toString();
            }
            tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound", displayName)
                    .method_27692(class_124.field_1075));
        }
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player.method_5715()) {
            player.method_6019(hand);
            return class_1271.method_22428(stack);
        }
        return class_1271.method_22430(stack);
    }

    @Override
    public int method_7881(class_1799 stack) {
        return 40;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 livingEntity) {
        if (!(livingEntity instanceof class_1657 player)) return stack;
        if (!level.field_9236) {
            Optional<UUID> currentOwner = ModDataComponents.getBoundPlayer(stack);
            if (currentOwner.isPresent() && currentOwner.get().equals(player.method_5667())) {
                ModDataComponents.removeBoundPlayer(stack);
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".unbound"), true);
            } else {
                ModDataComponents.setBoundPlayer(stack, player.method_5667());
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound"), true);
            }
        }
        return stack;
    }

    public abstract int getLevel(class_1799 stack);

    public abstract double getMultiplier(class_1799 stack);

    /**
     * 带世界上下文的等级（默认委托给仅依赖物品的版本）。
     * 时间手札等按世界时间计算进度的手札需重写此方法。
     */
    public int getLevel(class_1799 stack, class_1937 level) {
        return getLevel(stack);
    }

    /**
     * 带世界上下文的倍率（默认委托给仅依赖物品的版本）。
     * 时间手札等按世界时间计算进度的手札需重写此方法。
     */
    public double getMultiplier(class_1799 stack, class_1937 level) {
        return getMultiplier(stack);
    }

    /**
     * 非阶段手札的行为进度总计数文本（tooltip 显示当前进度）。
     * 各子类按其行为计数显示；返回 null 表示不显示。
     */
    protected String getProgressRingText(class_1799 stack, class_1937 level) {
        if (this instanceof KillMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_kill",
                    LEVEL_FORMAT.format(KillMagicLetterItem.getKills(stack))).getString();
        }
        if (this instanceof TenacityMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_tenacity",
                    VALUE_FORMAT.format(TenacityMagicLetterItem.getDamageTaken(stack))).getString();
        }
        if (this instanceof ExperienceMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_experience",
                    LEVEL_FORMAT.format((long) ExperienceMagicLetterItem.getExperience(stack))).getString();
        }
        if (this instanceof FishingMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_fish",
                    LEVEL_FORMAT.format(FishingMagicLetterItem.getFish(stack))).getString();
        }
        if (this instanceof TreasureMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_treasure",
                    LEVEL_FORMAT.format(TreasureMagicLetterItem.getOpens(stack))).getString();
        }
        if (this instanceof HeroMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_hero",
                    LEVEL_FORMAT.format(HeroMagicLetterItem.getVictories(stack))).getString();
        }
        if (this instanceof TravelMagicLetterItem) {
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_travel",
                    VALUE_FORMAT.format(TravelMagicLetterItem.getWalkDistance(stack)),
                    VALUE_FORMAT.format(TravelMagicLetterItem.getFlyDistance(stack))).getString();
        }
        if (this instanceof TimeMagicLetterItem) {
            int t = getLevel(stack, level);
            return class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".progress_time",
                    LEVEL_FORMAT.format(t)).getString();
        }
        return null;
    }
}
