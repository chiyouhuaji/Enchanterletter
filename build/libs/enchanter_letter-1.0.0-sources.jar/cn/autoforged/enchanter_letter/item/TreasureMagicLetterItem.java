package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class TreasureMagicLetterItem extends MagicLetterItem {
    public TreasureMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addOpen(class_1799 stack) {
        stack.method_57379(ModDataComponents.TREASURE_OPENS, getOpens(stack) + 1);
    }

    public static int getOpens(class_1799 stack) {
        return stack.method_57825(ModDataComponents.TREASURE_OPENS, 0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        double opensPerLevel = ModConfig.getInstance().treasureLetter.opensPerLevel;
        return (int) (getOpens(stack) / opensPerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().treasureLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
