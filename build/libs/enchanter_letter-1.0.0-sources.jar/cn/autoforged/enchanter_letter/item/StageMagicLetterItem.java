package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.config.ModConfig;
import java.util.List;
import net.minecraft.class_1799;

public class StageMagicLetterItem extends MagicLetterItem {
    private final int stage;

    public StageMagicLetterItem(class_1793 properties, int stage) {
        super(properties);
        this.stage = stage;
    }

    @Override
    public int getLevel(class_1799 stack) {
        return stage;
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        var multipliers = ModConfig.getInstance().stageLetters.multipliers;
        if (stage >= 1 && stage <= multipliers.size()) {
            Double val = multipliers.get(stage - 1);
            if (val != null) return val;
        }
        return stage;
    }
}
