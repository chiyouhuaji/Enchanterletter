package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class FishingMagicLetterItem extends MagicLetterItem {
    public FishingMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addFish(class_1799 stack) {
        stack.method_57379(ModDataComponents.FISH_COUNT, getFish(stack) + 1);
    }

    public static int getFish(class_1799 stack) {
        return stack.method_57825(ModDataComponents.FISH_COUNT, 0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        double fishPerLevel = ModConfig.getInstance().fishingLetter.fishPerLevel;
        return (int) (getFish(stack) / fishPerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().fishingLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
