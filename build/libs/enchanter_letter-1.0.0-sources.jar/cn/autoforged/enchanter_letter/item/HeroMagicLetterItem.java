package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class HeroMagicLetterItem extends MagicLetterItem {
    public HeroMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addVictory(class_1799 stack) {
        stack.method_57379(ModDataComponents.RAID_VICTORIES, getVictories(stack) + 1);
    }

    public static int getVictories(class_1799 stack) {
        return stack.method_57825(ModDataComponents.RAID_VICTORIES, 0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        int victoriesPerLevel = ModConfig.getInstance().heroLetter.victoriesPerLevel;
        return getVictories(stack) / Math.max(1, victoriesPerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        ModConfig.HeroLetterConfig cfg = ModConfig.getInstance().heroLetter;
        int level = getLevel(stack);
        double mult = 0;
        for (int i = 1; i <= level; i++) {
            mult += (i < cfg.highLevelStart) ? cfg.growthLowLevels : cfg.growthHighLevels;
        }
        return mult;
    }
}
