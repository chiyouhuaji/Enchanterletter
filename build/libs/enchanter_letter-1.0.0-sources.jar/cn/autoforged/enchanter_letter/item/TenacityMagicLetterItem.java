package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class TenacityMagicLetterItem extends MagicLetterItem {
    public TenacityMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addDamage(class_1799 stack, double amount) {
        ModDataComponents.setDouble(stack, ModDataComponents.DAMAGE_TAKEN, getDamageTaken(stack) + amount);
    }

    public static double getDamageTaken(class_1799 stack) {
        return ModDataComponents.getDouble(stack, ModDataComponents.DAMAGE_TAKEN, 0.0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        double damagePerLevel = ModConfig.getInstance().tenacityLetter.damagePerLevel;
        return (int) (getDamageTaken(stack) / damagePerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        double growthPerLevel = ModConfig.getInstance().tenacityLetter.growthPerLevel;
        return getLevel(stack) * growthPerLevel;
    }
}
