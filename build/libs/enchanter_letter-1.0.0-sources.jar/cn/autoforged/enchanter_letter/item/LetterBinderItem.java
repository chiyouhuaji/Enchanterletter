package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5536;
import net.minecraft.class_5537;
import net.minecraft.class_5630;
import net.minecraft.class_640;
import net.minecraft.class_9276;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

/**
 * 手札合订本：工作方式与原版收纳袋（Bundle）一致。
 */
public class LetterBinderItem extends class_5537 {
    public LetterBinderItem(class_1793 properties) {
        super(properties);
    }

    /** 手札合订本无附魔意义：禁止一切附魔途径（附魔台/铁砧/命令），包含“魔法转化”。 */
    @Override
    public boolean method_7870(class_1799 stack) {
        return false;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 binder = player.method_5998(hand);
        class_9276 currentContents = binder.method_57825(class_9334.field_49650, class_9276.field_49289);

        // 内容物为空 + 潜行：进入绑定/解绑操作
        if (currentContents.method_57429() && player.method_18276()) {
            player.method_6019(hand);
            return class_1271.method_22428(binder);
        }

        // 存储：另一只手持有物品时，把物品放入合订本
        class_1268 otherHand = hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
        class_1799 held = player.method_5998(otherHand);
        if (canInsert(held)) {
            class_9276 contents = binder.method_57825(class_9334.field_49650, class_9276.field_49289);
            class_9276.class_9277 mutable = new class_9276.class_9277(contents);
            int inserted = mutable.method_57432(held);
            if (inserted > 0) {
                held.method_7934(inserted);
                binder.method_57379(class_9334.field_49650, mutable.method_57435());
                ensureIcon(binder);
                playSound(player, class_3417.field_34376);
                return class_1271.method_29237(binder, level.field_9236);
            }
            return class_1271.method_22431(binder);
        }

        // 潜行右键：全部放出
        if (player.method_18276()) {
            class_9276 contents = binder.method_57825(class_9334.field_49650, class_9276.field_49289);
            if (!contents.method_57429()) {
                for (class_1799 inner : contents.method_59708()) {
                    player.method_7328(inner, false);
                }
                binder.method_57379(class_9334.field_49650, class_9276.field_49289);
                ensureIcon(binder);
                playSound(player, class_3417.field_34375);
                return class_1271.method_29237(binder, level.field_9236);
            }
            return class_1271.method_22431(binder);
        }

        // 普通右键：取出一件到背包
        class_9276 contents = binder.method_57825(class_9334.field_49650, class_9276.field_49289);
        if (!contents.method_57429()) {
            class_9276.class_9277 mutable = new class_9276.class_9277(contents);
            class_1799 taken = mutable.method_57430();
            if (taken != null && !taken.method_7960()) {
                binder.method_57379(class_9334.field_49650, mutable.method_57435());
                ensureIcon(binder);
                if (!player.method_31548().method_7394(taken)) {
                    player.method_7328(taken, false);
                }
                playSound(player, class_3417.field_34377);
                return class_1271.method_29237(binder, level.field_9236);
            }
        }
        return class_1271.method_22431(binder);
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 other, class_1735 slot,
                                            class_5536 action, class_1657 player, class_5630 slotAccess) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        if (other.method_7960()) {
            class_9276.class_9277 mutable = new class_9276.class_9277(contents);
            class_1799 taken = mutable.method_57430();
            if (taken == null || taken.method_7960()) return false;
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            ensureIcon(stack);
            slotAccess.method_32332(taken);
            playSound(player, class_3417.field_34377);
            return true;
        }
        if (!canInsert(other)) return false;
        class_9276.class_9277 mutable = new class_9276.class_9277(contents);
        int inserted = mutable.method_57432(other);
        if (inserted > 0) {
            other.method_7934(inserted);
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            ensureIcon(stack);
            playSound(player, class_3417.field_34376);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        if (slot.method_7677().method_7960()) {
            class_9276.class_9277 mutable = new class_9276.class_9277(contents);
            class_1799 taken = mutable.method_57430();
            if (taken == null || taken.method_7960()) return false;
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            ensureIcon(stack);
            slot.method_32756(taken);
            playSound(player, class_3417.field_34377);
            return true;
        }
        if (!canInsert(slot.method_7677())) return false;
        class_9276.class_9277 mutable = new class_9276.class_9277(contents);
        int inserted = mutable.method_57432(slot.method_7677());
        if (inserted > 0) {
            slot.method_7677().method_7934(inserted);
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            ensureIcon(stack);
            playSound(player, class_3417.field_34376);
            return true;
        }
        return false;
    }

    private static boolean canInsert(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() instanceof MagicLetterItem;
    }

    public static void ensureIcon(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof LetterBinderItem)) return;
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        int target = contents.method_57429() ? 0 : 1;
        class_9280 current = stack.method_57824(class_9334.field_49637);
        if (current == null || current.comp_2382() != target) {
            stack.method_57379(class_9334.field_49637, new class_9280(target));
        }
    }

    private static void playSound(class_1657 player, class_3414 sound) {
        player.method_5783(sound, 0.8F, 0.8F + player.method_37908().method_8409().method_43057() * 0.4F);
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return 40;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 livingEntity) {
        if (!(livingEntity instanceof class_1657 player)) return stack;
        if (!level.field_9236) {
            Optional<UUID> currentOwner = stack.method_57824(ModDataComponents.BOUND_PLAYER);
            if (currentOwner != null && currentOwner.isPresent() && currentOwner.get().equals(player.method_5667())) {
                stack.method_57381(ModDataComponents.BOUND_PLAYER);
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".unbound"), true);
            } else {
                stack.method_57379(ModDataComponents.BOUND_PLAYER, Optional.of(player.method_5667()));
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound"), true);
            }
        }
        return stack;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        super.method_7851(stack, context, tooltipComponents, tooltipFlag);
        Optional<UUID> owner = stack.method_57824(ModDataComponents.BOUND_PLAYER);
        if (owner != null && owner.isPresent()) {
            String displayName;
            try {
                net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
                if (mc.method_1562() != null) {
                    var playerInfo = mc.method_1562().method_2871(owner.get());
                    displayName = playerInfo != null ? playerInfo.method_2966().getName() : owner.get().toString();
                } else {
                    displayName = owner.get().toString();
                }
            } catch (Throwable e) {
                displayName = owner.get().toString();
            }
            tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound", displayName)
                    .method_27692(class_124.field_1075));
        }
    }
}
