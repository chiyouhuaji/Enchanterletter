package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.UsefulMagicEnchanterLetterMod;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5536;
import net.minecraft.class_5537;
import net.minecraft.class_5630;
import net.minecraft.class_640;

/**
 * 鎵嬫湱鍚堣鏈紙1.20.1 绉绘锛夛細宸ヤ綔鏂瑰紡涓庡師鐗堟敹绾宠锛圔undle锛変竴鑷达紙NBT 瀛樺偍锛屾牸寮忎笌鍘熺増鍏煎锛? * "Items" 鍒楄〃 + "Weight" 鏁存暟锛夈€傚彧鍏佽瑁呭叆鏈ā缁勭殑鎵嬫湱锛圡agicLetterItem锛夈€? */
public class LetterBinderItem extends class_5537 {
    private static final int field_30857 = 64;
    private static final String TAG_ITEMS = "Items";
    private static final String TAG_WEIGHT = "Weight";

    public LetterBinderItem(class_1793 properties) {
        super(properties);
    }

    /** 手札合订本无附魔意义：禁止一切附魔途径（附魔台/铁砧/命令），包含“魔法转化”。 */
    @Override
    public boolean method_7870(class_1799 stack) {
        return false;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 binder = player.method_5998(hand);

        // 0) 鍐呭鐗╀负绌?+ 娼滆锛氳繘鍏ョ粦瀹?瑙ｇ粦鎿嶄綔锛堜笌鍏朵粬鎵嬫湱涓€鑷达紝闀挎寜鍙抽敭 2 绉掕Е鍙戯級
        if (method_31563(binder) == 0 && player.method_18276()) {
            player.method_6019(hand);
            return class_1271.method_22428(binder);
        }

        // 1) 瀛樺偍锛氬彟涓€鍙墜鎸佹湁鐗╁搧鏃讹紝鎶婄墿鍝佹斁鍏ュ悎璁㈡湰锛堝師鐗堝閲忛檺鍒讹級
        class_1268 otherHand = hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
        class_1799 held = player.method_5998(otherHand);
        if (canInsert(held)) {
            int inserted = tryInsert(binder, held);
            if (inserted > 0) {
                held.method_7934(inserted);
                ensureIcon(binder);
                playSound(player, class_3417.field_34376);
                return class_1271.method_29237(binder, level.field_9236);
            }
            return class_1271.method_22431(binder);
        }

        // 2) 娼滆鍙抽敭锛氬叏閮ㄦ斁鍑?
if (player.method_18276()) {
            class_2371<class_1799> contents = readContents(binder);
            if (!contents.isEmpty()) {
                for (class_1799 inner : contents) {
                    player.method_7328(inner, false);
                }
                writeContents(binder, class_2371.method_10213(0, class_1799.field_8037));
                binder.method_7948().method_10569(TAG_WEIGHT, 0);
                ensureIcon(binder);
                playSound(player, class_3417.field_34375);
                return class_1271.method_29237(binder, level.field_9236);
            }
            return class_1271.method_22431(binder);
        }

        // 3) 鏅€氬彸閿細鍙栧嚭涓€浠跺埌鑳屽寘锛堣儗鍖呮弧鍒欐帀钀斤級
        if (method_31563(binder) > 0) {
            class_1799 taken = removeOne(binder);
            if (!taken.method_7960()) {
                ensureIcon(binder);
                if (!player.method_31548().method_7394(taken)) {
                    player.method_7328(taken, false);
                }
                playSound(player, class_3417.field_34377);
                return class_1271.method_29237(binder, level.field_9236);
            }
        }
        return class_1271.method_22431(binder);
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 other, class_1735 slot,
                                            class_5536 action, class_1657 player, class_5630 slotAccess) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;
        if (other.method_7960()) {
            class_1799 taken = removeOne(stack);
            if (taken.method_7960()) return false;
            ensureIcon(stack);
            slotAccess.method_32332(taken);
            playSound(player, class_3417.field_34377);
            return true;
        }
        if (!canInsert(other)) return false;
        int inserted = tryInsert(stack, other);
        if (inserted > 0) {
            other.method_7934(inserted);
            ensureIcon(stack);
            playSound(player, class_3417.field_34376);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;
        if (slot.method_7677().method_7960()) {
            class_1799 taken = removeOne(stack);
            if (taken.method_7960()) return false;
            ensureIcon(stack);
            slot.method_32756(taken);
            playSound(player, class_3417.field_34377);
            return true;
        }
        if (!canInsert(slot.method_7677())) return false;
        int inserted = tryInsert(stack, slot.method_7677());
        if (inserted > 0) {
            slot.method_7677().method_7934(inserted);
            ensureIcon(stack);
            playSound(player, class_3417.field_34376);
            return true;
        }
        return false;
    }

    /** 鍚堣鏈彧鍏佽瑁呭叆鏈ā缁勭殑鎵嬫湱锛堜笉鍚悎璁㈡湰鏈韩涓庡叾浠栫墿鍝侊級銆?*/
    private static boolean canInsert(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() instanceof MagicLetterItem;
    }

    /** 褰撳墠鍐呭鐗╅噸閲忥紙0~64锛夈€?*/
    public static int method_31563(class_1799 stack) {
        if (!stack.method_7985()) return 0;
        return stack.method_7969().method_10550(TAG_WEIGHT);
    }

    /** 璇诲彇鍐呭鐗╁垪琛紙鍘熺増 NBT 鏍煎紡锛夈€?*/
    public static class_2371<class_1799> readContents(class_1799 stack) {
        class_2371<class_1799> list = class_2371.method_10211();
        if (!stack.method_7985()) return list;
        class_2499 items = stack.method_7969().method_10554(TAG_ITEMS, class_2520.field_33260);
        for (int i = 0; i < items.size(); i++) {
            class_1799 s = class_1799.method_7915(items.method_10602(i));
            if (!s.method_7960()) list.add(s);
        }
        return list;
    }

    /** 鍐欏叆鍐呭鐗╁垪琛紙鍘熺増 NBT 鏍煎紡锛夈€?*/
    public static void writeContents(class_1799 stack, class_2371<class_1799> contents) {
        class_2499 items = new class_2499();
        for (class_1799 s : contents) {
            if (!s.method_7960()) {
                items.add(s.method_7953(new class_2487()));
            }
        }
        stack.method_7948().method_10566(TAG_ITEMS, items);
    }

    /** 鐗╁搧鍦ㄥ悎璁㈡湰涓殑閲嶉噺锛堜笌鍘熺増涓€鑷达細鎵嬫湱鍗犳弧 1 鏍硷級銆?*/
    private static int itemWeight(class_1799 stack) {
        if (stack.method_7909() instanceof MagicLetterItem) return 1;
        if (stack.method_7909() instanceof class_5537) return 4;
        return Math.max(1, (int) Math.ceil(1.0F / stack.method_7914()));
    }

    /** 灏濊瘯鏀惧叆涓€浠剁墿鍝侊紙姣忔鏀惧叆 1 浠讹紝鎵嬫湱涓嶅彲鍫嗗彔锛夈€傝繑鍥炴斁鍏ユ暟閲忥紙0 鎴?1锛夈€?*/
    private static int tryInsert(class_1799 binder, class_1799 insert) {
        if (insert.method_7960()) return 0;
        class_2371<class_1799> contents = readContents(binder);
        int weight = method_31563(binder);
        if (weight + itemWeight(insert) > field_30857) return 0;
        contents.add(insert.method_7972());
        writeContents(binder, contents);
        binder.method_7948().method_10569(TAG_WEIGHT, weight + itemWeight(insert));
        return 1;
    }

    /** 鍙栧嚭涓€浠讹紙鎸夋斁鍏ラ『搴忥級銆?*/
    private static class_1799 removeOne(class_1799 binder) {
        class_2371<class_1799> contents = readContents(binder);
        if (contents.isEmpty()) return class_1799.field_8037;
        class_1799 taken = contents.remove(contents.size() - 1);
        writeContents(binder, contents);
        int weight = Math.max(0, method_31563(binder) - itemWeight(taken));
        binder.method_7948().method_10569(TAG_WEIGHT, weight);
        return taken;
    }

    /**
     * 鍚屾鏄剧ず鍥炬爣锛氬唴瀹圭墿涓虹┖ 鈫?绌哄悎璁㈡湰锛坈ustom_model_data=0锛夛紱鏈夊唴瀹圭墿 鈫?鏈夋墜鏈悎璁㈡湰锛坈ustom_model_data=1锛夈€?     */
    public static void ensureIcon(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof LetterBinderItem)) return;
        int target = method_31563(stack) > 0 ? 1 : 0;
        stack.method_7948().method_10569("CustomModelData", target);
    }

    private static void playSound(class_1657 player, class_3414 sound) {
        player.method_5783(sound, 0.8F, 0.8F + player.method_37908().method_8409().method_43057() * 0.4F);
    }

    @Override
    public int method_7881(class_1799 stack) {
        return 40;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 livingEntity) {
        if (!(livingEntity instanceof class_1657 player)) return stack;
        if (!level.field_9236) {
            Optional<UUID> currentOwner = ModDataComponents.getBoundPlayer(stack);
            if (currentOwner.isPresent() && currentOwner.get().equals(player.method_5667())) {
                ModDataComponents.removeBoundPlayer(stack);
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".unbound"), true);
            } else {
                ModDataComponents.setBoundPlayer(stack, player.method_5667());
                player.method_7353(class_2561.method_43471("message." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound"), true);
            }
        }
        return stack;
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 level, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        super.method_7851(stack, level, tooltipComponents, tooltipFlag);
        Optional<UUID> owner = ModDataComponents.getBoundPlayer(stack);
        if (owner.isPresent()) {
            String displayName;
            try {
                net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
                if (mc.method_1562() != null) {
                    var playerInfo = mc.method_1562().method_2871(owner.get());
                    displayName = playerInfo != null ? playerInfo.method_2966().getName() : owner.get().toString();
                } else {
                    displayName = owner.get().toString();
                }
            } catch (Throwable e) {
                displayName = owner.get().toString();
            }
            tooltipComponents.add(class_2561.method_43469("tooltip." + UsefulMagicEnchanterLetterMod.MOD_ID + ".bound", displayName)
                    .method_27692(class_124.field_1075));
        }
    }
}
