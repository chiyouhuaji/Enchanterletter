package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class TimeMagicLetterItem extends MagicLetterItem {
    public TimeMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    /**
     * 按世界开启时间（服务器 GameTime）计算倍率，与玩家持有时间无关。
     */
    public static double getMultiplier(class_1937 level) {
        if (level == null) return 0;
        ModConfig.TimeLetterConfig cfg = ModConfig.getInstance().timeLetter;
        double seconds = level.method_8510() / 20.0;
        double levels = Math.floor(seconds / cfg.secondsPerLevel);
        return levels * cfg.growthPerLevel;
    }

    @Override
    public int getLevel(class_1799 stack) {
        return 0;
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        return 0;
    }

    @Override
    public int getLevel(class_1799 stack, class_1937 level) {
        if (level == null) return 0;
        ModConfig.TimeLetterConfig cfg = ModConfig.getInstance().timeLetter;
        double seconds = level.method_8510() / 20.0;
        return (int) Math.floor(seconds / cfg.secondsPerLevel);
    }

    @Override
    public double getMultiplier(class_1799 stack, class_1937 level) {
        return getMultiplier(level);
    }
}
