package cn.autoforged.enchanter_letter.item;

import cn.autoforged.enchanter_letter.ModDataComponents;
import cn.autoforged.enchanter_letter.config.ModConfig;
import net.minecraft.class_1799;

public class TravelMagicLetterItem extends MagicLetterItem {
    public TravelMagicLetterItem(class_1793 properties) {
        super(properties);
    }

    public static void addDistance(class_1799 stack, double walk, double fly) {
        stack.method_57379(ModDataComponents.WALK_DISTANCE, getWalkDistance(stack) + walk);
        stack.method_57379(ModDataComponents.FLY_DISTANCE, getFlyDistance(stack) + fly);
    }

    public static double getWalkDistance(class_1799 stack) {
        return stack.method_57825(ModDataComponents.WALK_DISTANCE, 0.0);
    }

    public static double getFlyDistance(class_1799 stack) {
        return stack.method_57825(ModDataComponents.FLY_DISTANCE, 0.0);
    }

    @Override
    public int getLevel(class_1799 stack) {
        ModConfig.TravelLetterConfig cfg = ModConfig.getInstance().travelLetter;
        int walkLevel = (int) (getWalkDistance(stack) / cfg.walkDistancePerLevel);
        int flyLevel = (int) (getFlyDistance(stack) / cfg.flyDistancePerLevel);
        return walkLevel + flyLevel;
    }

    @Override
    public double getMultiplier(class_1799 stack) {
        ModConfig.TravelLetterConfig cfg = ModConfig.getInstance().travelLetter;
        double walkLevels = Math.floor(getWalkDistance(stack) / cfg.walkDistancePerLevel);
        double flyLevels = Math.floor(getFlyDistance(stack) / cfg.flyDistancePerLevel);
        return walkLevels * cfg.walkGrowthPerLevel + flyLevels * cfg.flyGrowthPerLevel;
    }
}
