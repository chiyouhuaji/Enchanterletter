package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_2614;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 阻止漏斗 / 漏斗矿车自动吸入手札掉落物。
 */
@Mixin(class_2614.class)
public class HopperBlockEntityMixin {

    @Inject(method = "addItem(Lnet/minecraft/world/Container;Lnet/minecraft/world/entity/item/ItemEntity;)Z", at = @At("HEAD"), cancellable = true, remap = true)
    private static void blockLetterSuction(net.minecraft.class_1263 container,
                                           net.minecraft.class_1542 itemEntity,
                                           CallbackInfoReturnable<Boolean> cir) {
        if (itemEntity != null && ModCommonEvents.isOurLetter(itemEntity.method_6983())) {
            cir.setReturnValue(false);
        }
    }
}
