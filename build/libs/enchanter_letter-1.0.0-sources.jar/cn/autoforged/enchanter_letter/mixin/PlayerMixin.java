package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public class PlayerMixin {

    @Inject(method = "giveExperiencePoints", at = @At("TAIL"))
    private void onGiveExperiencePoints(int amount, CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        ModCommonEvents.onXpGained(self, amount);
    }
}
