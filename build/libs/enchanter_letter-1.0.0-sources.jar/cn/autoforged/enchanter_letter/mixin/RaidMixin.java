package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 村庄袭击胜利（Raid 为村庄英雄名单添加玩家）时给英雄手札计数。
 */
@Mixin(class_3765.class)
public class RaidMixin {

    @Inject(method = "addHeroOfTheVillage", at = @At("HEAD"))
    private void onAddHeroOfTheVillage(class_1297 entity, CallbackInfo ci) {
        if (entity instanceof class_1657 player && !entity.method_37908().field_9236) {
            ModCommonEvents.onRaidVictory(player);
        }
    }
}
