package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.enchantment.ModEnchantments;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class HandItemUseMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void onUse(class_1937 level, class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1271<class_1799>> cir) {
        if (level.field_9236 && player.method_7337()) {
            class_1799 self = (class_1799) (Object) this;
            if (self.method_7909() == class_1802.field_8598) {
                if (ModEnchantments.hasMagicConversion(self)) {
                    class_310.method_1551().method_1507(
                            new cn.autoforged.enchanter_letter.screen.ConversionDamageTypeScreen(self));
                    cir.setReturnValue(class_1271.method_22427(self));
                }
            }
        }
    }
}
