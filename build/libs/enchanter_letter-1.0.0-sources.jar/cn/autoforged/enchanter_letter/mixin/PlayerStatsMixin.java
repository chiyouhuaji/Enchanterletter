package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import net.minecraft.class_3468;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 捕获一条鱼时给垂钓魔法手札计数（服务器统计 minecraft:fish_caught）。
 */
@Mixin(class_3222.class)
public class PlayerStatsMixin {

    @Inject(method = "awardStat", at = @At("HEAD"))
    private void onAwardStat(class_3445<?> stat, int amount, CallbackInfo ci) {
        if (stat.method_14949() == class_3468.field_15419
                && stat.method_14951() instanceof class_2960 rl
                && class_3468.field_15391.equals(rl)) {
            ModCommonEvents.onFishCaught((class_3222) (Object) this);
        }
    }
}
