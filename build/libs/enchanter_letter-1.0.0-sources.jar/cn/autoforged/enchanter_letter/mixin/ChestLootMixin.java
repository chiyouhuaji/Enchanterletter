package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_1657;
import net.minecraft.class_2595;
import net.minecraft.class_2621;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 玩家首次开启“未刷新”（仍有战利品表，即自然生成且未开过）的箱子时，给宝藏魔法手札计数。
 */
@Mixin(class_2621.class)
public abstract class ChestLootMixin {

    @Shadow
    protected class_2960 lootTable;

    @Inject(method = "unpackLootTable(Lnet/minecraft/world/entity/player/Player;)V", at = @At("HEAD"))
    private void onUnpackLootTable(class_1657 player, CallbackInfo ci) {
        if (player == null) return;
        if (!((Object) this instanceof class_2595 chest)) return;
        if (chest.method_10997() == null || chest.method_10997().field_9236) return;
        if (lootTable == null) return;
        ModCommonEvents.onTreasureOpened(player);
    }
}
