package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.ModCommonEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1542.class)
public class ItemEntityMixin {

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void onItemEntityHurt(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (ModCommonEvents.shouldProtectItemDrop((class_1542) (Object) this, source)) {
            cir.setReturnValue(false);
        }
    }

    /** 手札掉落物每 tick 再次保证无重力且速度归零。 */
    @Inject(method = "tick", at = @At("TAIL"))
    private void keepLetterDropStill(CallbackInfo ci) {
        class_1542 self = (class_1542) (Object) this;
        if (ModCommonEvents.isOurLetter(self.method_6983())) {
            self.method_5875(true);
            self.method_18800(0.0, 0.0, 0.0);
        }
    }
}
