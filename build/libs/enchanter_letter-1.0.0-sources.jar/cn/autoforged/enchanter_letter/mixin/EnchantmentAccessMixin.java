package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.item.LetterBinderItem;
import cn.autoforged.enchanter_letter.item.MagicLetterItem;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2588;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 附魔放行：
 * - 魔法绑定（magic_binding）：不限制模组物品，任意物品均可附魔（附魔台/铁砧/命令）；
 * - 消失诅咒（vanishing_curse）：允许附魔到本模组所有物品（手札/手札合订本）。
 * 光灵（glowing）由 supported_items 标签控制，无需放行。
 */
@Mixin(class_1887.class)
public class EnchantmentAccessMixin {

    @Inject(method = "canEnchant", at = @At("RETURN"), cancellable = true)
    private void enchanterLetter$allowEnchant(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) return;
        class_1887 self = (class_1887) (Object) this;
        String key = "";
        if (self.comp_2686().method_10851() instanceof class_2588 contents) {
            key = contents.method_11022();
        }
        if ("enchantment.enchanter_letter.magic_binding".equals(key)) {
            // 魔法绑定：只允许附魔到本模组物品，或已注册到饰品模组（Curios/Accessories）物品标签的物品
            if (isModItem(stack) || hasAccessoryTag(stack)) {
                cir.setReturnValue(true);
            }
            return;
        }
        if ("enchantment.minecraft.vanishing_curse".equals(key)) {
            if (stack.method_7909() instanceof MagicLetterItem || stack.method_7909() instanceof LetterBinderItem) {
                cir.setReturnValue(true);
            }
        }
    }

    private static boolean isModItem(class_1799 stack) {
        return stack.method_7909() instanceof MagicLetterItem || stack.method_7909() instanceof LetterBinderItem;
    }

    private static boolean hasAccessoryTag(class_1799 stack) {
        return stack.method_41409().method_40228()
                .anyMatch(tag -> {
                    String ns = tag.comp_327().method_12836();
                    return "curios".equals(ns) || "accessories".equals(ns);
                });
    }
}
