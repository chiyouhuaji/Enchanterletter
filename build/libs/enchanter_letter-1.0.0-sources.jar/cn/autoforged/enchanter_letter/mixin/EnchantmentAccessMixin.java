package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.item.LetterBinderItem;
import cn.autoforged.enchanter_letter.item.MagicLetterItem;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 附魔放行（Fabric 1.20.1）：
 * - 魔法绑定（magic_binding）：canEnchant 已在注册时覆盖为任意物品均 true，无需放行；
 * - 消失诅咒（vanishing_curse）：允许附魔到本模组所有物品（手札/手札合订本）。
 * 光灵（glowing）的 canEnchant 已在注册时限定本模组物品，无需放行。
 * 通过 getDescriptionId() 识别附魔（Equivalent "enchantment.<ns>.<path>"）。
 */
@Mixin(class_1887.class)
public class EnchantmentAccessMixin {

    @Inject(method = "canEnchant", at = @At("RETURN"), cancellable = true)
    private void enchanterLetter$allowEnchant(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) return;
        class_1887 self = (class_1887) (Object) this;
        if ("enchantment.minecraft.vanishing_curse".equals(self.method_8184())) {
            if (stack.method_7909() instanceof MagicLetterItem || stack.method_7909() instanceof LetterBinderItem) {
                cir.setReturnValue(true);
            }
        }
    }
}