package cn.autoforged.enchanter_letter.mixin;

import cn.autoforged.enchanter_letter.event.LetterEntityEffects;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class MobDeathEffectsMixin {

    @Inject(method = "die", at = @At("HEAD"))
    private void enchanterLetter$onLivingDeath(class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!(self instanceof class_1657)) {
            LetterEntityEffects.handleMobDeath(self);
        }
    }
}